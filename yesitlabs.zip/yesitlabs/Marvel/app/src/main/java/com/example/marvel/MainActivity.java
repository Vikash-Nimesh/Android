package com.example.marvel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private Api api;
    private RecyclerView recyclerView;
    private ArrayList<Model> dataList;
    private String BaseUrl="https://simplifiedcoding.net/demos/marvel/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataList = new ArrayList<>();
        recyclerView=findViewById(R.id.rcv);

        runRetrofit();
        Toast.makeText(this, "App Started", Toast.LENGTH_SHORT).show();

    }


    public void runRetrofit(){

        Api myWebService = Api.retrofit.create(Api.class);
        Call<ArrayList<Model>> call = myWebService.getPost();

        call.enqueue(new Callback<ArrayList<Model>>() {
            @Override
            public void onResponse(Call<ArrayList<Model>> call, Response<ArrayList<Model>> response) {

                if (response.isSuccessful()){
                    dataList = response.body();
                    RCVAdapter rcvAdapter=new RCVAdapter(dataList,MainActivity.this,MainActivity.this);

                    LinearLayoutManager manager=new LinearLayoutManager (MainActivity.this,RecyclerView.VERTICAL,false );

                    recyclerView.setLayoutManager ( manager );
                    recyclerView.setAdapter ( rcvAdapter );

                }

            }

            @Override
            public void onFailure(Call<ArrayList<Model>> call, Throwable t) {

            }
        });

    }
}