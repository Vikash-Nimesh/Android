package com.example.marvel;


import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class DetailsDialog {

    public void showDialog(final Activity activity, ArrayList<Model> dataList, int position) {

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.details_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));


        final TextView name = dialog.findViewById(R.id.engName);
        final TextView tv_realname = dialog.findViewById(R.id.tv_realname);
        final TextView tv_team = dialog.findViewById(R.id.tv_team);
        final TextView tv_appear = dialog.findViewById(R.id.tv_appear);
        final TextView tv_createdby = dialog.findViewById(R.id.tv_createdby);
        final TextView tv_publisher = dialog.findViewById(R.id.tv_publisher);
        final ImageView imageView = dialog.findViewById(R.id.imageView);
        final TextView tv_bio = dialog.findViewById(R.id.tv_bio);

        name.setText(dataList.get(position).getName());
        tv_realname.setText(dataList.get(position).getRealname());
        tv_team.setText(dataList.get(position).getTeam());
        tv_appear.setText(dataList.get(position).getFirstappearance());
        tv_createdby.setText(dataList.get(position).getCreatedby());
        tv_publisher.setText(dataList.get(position).getPublisher());
        tv_bio.setText(dataList.get(position).getBio());


        Picasso.get().load(dataList.get(position).getImageurl()).into(imageView);



        dialog.show();
    }


    }


