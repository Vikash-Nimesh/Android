package com.example.marvel;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Headers;

interface Api {
    String BASE_URL = "https://simplifiedcoding.net/demos/";
    String FEED_URL = "marvel";

    Retrofit retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();

    @GET(FEED_URL)
    Call<ArrayList<Model>> getPost();
}
