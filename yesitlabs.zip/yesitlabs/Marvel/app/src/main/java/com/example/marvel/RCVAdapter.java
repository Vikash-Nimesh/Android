package com.example.marvel;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RCVAdapter extends RecyclerView.Adapter<RCVAdapter.myViewHolder> {

    private ArrayList<Model> dataList;
    private Context context;

    private Activity activity;

    public RCVAdapter(ArrayList<Model> dataList, Context context, Activity activity) {
        this.dataList = dataList;
        this.context = context;
        this.activity = activity;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from ( parent.getContext () ).inflate ( R.layout.rcvlist,parent,false );
        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        Model model = dataList.get(position);
        holder.nameTxtView.setText(model.getName());
        holder.nameTxtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DetailsDialog alert = new DetailsDialog();
                alert.showDialog(activity,dataList,position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView nameTxtView;
        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTxtView = itemView.findViewById(R.id.textView);

        }


    }

}
