package com.example.marghclone;


// IN THIS CASE NAME OF THE JAVA CLASS IS VideoAct
public class VideoAct {
    public String videoURL, videoTitle, VideoDescription;
}
