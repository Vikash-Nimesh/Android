package com.example.aajivikasetu.screen.fragment.main

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.aajivikasetu.R
import com.example.aajivikasetu.adapter.SkillAdapter
import com.example.aajivikasetu.adapter.listOfCheckItem
import com.example.aajivikasetu.databinding.FragmentProfileBinding
import com.example.aajivikasetu.di.UserModel
import com.example.aajivikasetu.model.blooddonar.Geo
import com.example.aajivikasetu.model.personaldetails.CareerDetails
import com.example.aajivikasetu.model.personaldetails.DocumentDetails
import com.example.aajivikasetu.model.personaldetails.EducationDetails
import com.example.aajivikasetu.model.personaldetails.KeySkills
import com.example.aajivikasetu.model.personaldetails.PaymentStatus
import com.example.aajivikasetu.model.personaldetails.PersonalDetails
import com.example.aajivikasetu.model.personaldetails.UserDetails
import com.example.aajivikasetu.screen.fragment.main.state.ShowProfileViewModel
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.StateAndDistrict
import com.example.aajivikasetu.utils.companyList
import com.example.aajivikasetu.utils.countries
import com.example.aajivikasetu.utils.departmentList
import com.example.aajivikasetu.utils.desiredJobRole
import com.example.aajivikasetu.utils.getFileName
import com.example.aajivikasetu.utils.showAlert
import com.example.aajivikasetu.utils.showToast
import com.example.aajivikasetu.utils.toMap
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.FirebaseStorage
import dagger.hilt.android.AndroidEntryPoint
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.Calendar
import java.util.UUID
import javax.inject.Inject

@AndroidEntryPoint
class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding: FragmentProfileBinding by lazy { requireNotNull(_binding) }

    @Inject
    lateinit var sharedManager: SharedManager

    @Inject
    @UserModel
    lateinit var userDatabaseReference: DatabaseReference

    private var latitude: String? = null
    private var longitude: String? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val locationPermission = Manifest.permission.ACCESS_FINE_LOCATION

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                getLocation { _, _ ->

                }
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        requireActivity(),
                        locationPermission
                    )
                ) {
                    showPermissionRationale()
                }
            }
        }

    private var pdfUri: Uri? = null
    private var imageUri: Uri? = null
    private val PICK_PDF_REQUEST = 100
    private lateinit var progressbar: ProgressDialog
    private val showProfileViewModel by viewModels<ShowProfileViewModel>()

    @RequiresApi(Build.VERSION_CODES.N)
    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                locationPermission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            getLocation { latitude: String, longitude: String ->
                this.latitude = latitude
                this.longitude = longitude
            }
        } else {
            requestPermissionLauncher.launch(locationPermission)
        }

        setUpProgressDialog()
        binding.arrowBack.setOnClickListener {
            findNavController().popBackStack()
        }

        if (sharedManager.getImageUrl().isNotEmpty()) {
            Glide.with(requireContext()).load(sharedManager.getImageUrl())
                .into(binding.profileImage)
        }
        if (sharedManager.getEmailId().isNotEmpty()) {
            binding.emailId.text = sharedManager.getEmailId()
        }

        dropDownList()

        binding.uploadResume.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "application/pdf"
            startActivityForResult(intent, PICK_PDF_REQUEST)
        }
        binding.profileImage.setOnClickListener {
            selectImageFromGallery()
        }

        // for the fetch the data from firebase
        val userId = sharedManager.getUserUuid()
        getDataFromFirebase(userId)

        /*if (sharedManager.getPaymentId() == null){
            binding.submitButton.text = ""
        }*/

        if (sharedManager.getPaymentId() == null) {
            binding.submitButton.text = "Update Details"
        } else {
            binding.submitButton.text = "Save Details"
        }

        binding.selectDate.setOnClickListener {
            val c: Calendar = Calendar.getInstance()

            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog =
                DatePickerDialog(requireContext(), { view, year, month, dayOfMonth ->
                    binding.dateOfBirth.setText("$dayOfMonth/${month + 1}/$year")
                }, year, month, day)

            datePickerDialog.show()
        }


        binding.submitButton.setOnClickListener {
            //val resumeFileName = pdfUri?.getFileName(requireActivity())
            /*uploadResume(pdfUri, resumeFileName){resumePdfLink ->
                //uploadResumeData(resumePdfLink, sharedManager.getImageUrl())
                Log.d("rsumelink",resumePdfLink)
            }*/

            //val imageFileName = imageUri?.getFileName(requireActivity())
            /*uploadImage(imageUri!!, imageFileName) { profileImageLink ->
                Log.d("rsumelink",profileImageLink)
            }*/

            if (isValidCredential()) {
                Log.d("datacomessdf", "button click inside if")
                val resumeFileName = pdfUri?.getFileName(requireActivity())
                if (imageUri != null) {
                    Log.d("datacomessdf", "inside imageUri not null")
                    val imageFileName = imageUri?.getFileName(requireActivity())
                    if (imageFileName != null) {
                        uploadImage(imageUri!!, imageFileName) { profileImageLink ->
                            sharedManager.setImageUrl(profileImageLink)
                            showToast("profile photo uploaded")
                            if (resumeFileName != null) {
                                uploadResume(pdfUri, resumeFileName) { resumePdfLink ->
                                    uploadResumeData(profileImageLink, resumePdfLink)
                                }
                            }
                        }
                    }
                } else {
                    if (resumeFileName != null) {
                        uploadResume(pdfUri, resumeFileName) { resumePdfLink ->
                            uploadResumeData(resumePdfLink, sharedManager.getImageUrl())
                        }
                    } else {
                        showToast("Please upload resume")
                    }
                }
            } else {
                // if is not valid credential then which text field is empty then scroll which text filed
            }
        }

        binding.showSkill.setOnClickListener {
            if (binding.skillRecyclerview.visibility == View.VISIBLE) {
                binding.skillRecyclerview.visibility = View.GONE
                binding.showSkill.setImageResource(R.drawable.arrow_drop_down)
            } else {
                binding.skillRecyclerview.visibility = View.VISIBLE
                binding.showSkill.setImageResource(R.drawable.arrow_drop_up)
            }

        }

        val skillAndCheckBox = SkillAdapter(listOfCheckItem) {
            binding.skilled.text = it.joinToString(", ")
        }
        binding.skillRecyclerview.adapter = skillAndCheckBox
        binding.skillRecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.skillRecyclerview.setHasFixedSize(true)


        return binding.root
    }

    private fun getDataFromFirebase(userId: String) {
        showProfileViewModel.getUserData(userId)
        showProfileViewModel.userData.observe(viewLifecycleOwner) {
            when (it) {
                is ResultState.Loading -> {
                    binding.progressbar1.visibility = View.VISIBLE
                    binding.linearLayoutContent.visibility = View.GONE
                }

                is ResultState.Success -> {
                    if (it.data != null) {
                        fillTheData(it.data)
                    }
                    binding.progressbar1.visibility = View.GONE
                    binding.linearLayoutContent.visibility = View.VISIBLE
                }

                is ResultState.Error -> {
                    binding.progressbar1.visibility = View.GONE
                    binding.linearLayoutContent.visibility = View.VISIBLE
                    showToast(it.message.toString())
                }
            }
        }
    }

    private fun fillTheData(data: UserDetails) {
        binding.apply {
            // for personal details
            fullName.setText(data.name)
            userPhone.setText(data.personalDetails?.phone)
            gender.setText(data.personalDetails?.gender).toString()
            dateOfBirth.text = data.personalDetails?.dob
            maritialStatus.setText(data.personalDetails?.maritalStatus).toString()
            selectNationality.setText(data.personalDetails?.nationality)
            language.setText(data.personalDetails?.language)
            currentAddress.setText(data.personalDetails?.address)

            // for the education details
            secondarySchool.setText(data.educationDetails?.secondarySchool)
            higherSecondarySchool.setText(data.educationDetails?.higherSecondarySchool)
            diploma.setText(data.educationDetails?.diploma)
            bachelors.setText(data.educationDetails?.bachelor)
            postGraduation.setText(data.educationDetails?.postGrade)
            doctorate.setText(data.educationDetails?.doctorate)

            // fot the career details
            currentIndustry.setText(data.careerDetails?.currentIndustry)
            currentDepartment.setText(data.careerDetails?.department)
            desiredJobRole.setText(data.careerDetails?.desiredJobRole)
            workShift.setText(data.careerDetails?.preferredWorkShift)
            prefferedWorkLocation.setText(data.careerDetails?.preferredWorkLocation)

            // for the skill
            skilled.setText(data.keySkill?.skill)
            workStatus.setText(data.keySkill?.workStatus).toString()
            areaOfExperience.setText(data.keySkill?.areaOfEx)
            experienceInYear.setText(data.keySkill?.expYear)

            dropDownList()
        }
    }


    private fun uploadResumeData(resumePdfLink: String, imageUrl: String) {
        progressbar.show()
        // personal details
        val fullName = binding.fullName.text.toString()
        val phone = binding.userPhone.text.toString()
        val gender = binding.gender.text.toString()
        val dob = binding.dateOfBirth.text.toString()
        val martialStatus = binding.maritialStatus.text.toString()
        val nationality = binding.selectNationality.text.toString()
        val language = binding.language.text.toString()
        val address = binding.currentAddress.text.toString()

        // education details
        val secondarySchool = binding.secondarySchool.text.toString()
        val higherSecondarySchool = binding.higherSecondarySchool.text.toString()
        val diploma = binding.diploma.text.toString()
        val bachelor = binding.bachelors.text.toString()
        val postGrad = binding.postGraduation.text.toString()
        val doctorateGrade = binding.doctorate.text.toString()

        val lastEducationDetails = binding.lastEducationDetails.text.toString()

        // for the career details
        val currentIndustry = binding.currentIndustry.text.toString()
        val department = binding.currentDepartment.text.toString()
        val jobRole = binding.desiredJobRole.text.toString()
        val workShift = binding.workShift.text.toString()
        val workLocation = binding.prefferedWorkLocation.text.toString()

        // for the key kill details
        val skill = binding.skilled.text.toString()
        val workStatus = binding.workStatus.text.toString()
        val areaOfExp = binding.areaOfExperience.text.toString()
        val yearExp = binding.experienceInYear.text.toString()


        val data = UserDetails(
            name = fullName,
            personalDetails = PersonalDetails(
                summery = "",
                image = imageUrl,
                phone = phone,
                gender = gender,
                dob = dob,
                maritalStatus = martialStatus,
                nationality = nationality,
                language = language,
                address = address,
                geo = longitude?.let {
                    latitude?.let { it1 ->
                        Geo(
                            it1,
                            it
                        )
                    }
                }
            ),
            educationDetails = EducationDetails(
                secondarySchool = lastEducationDetails,
                higherSecondarySchool = higherSecondarySchool,
                diploma = diploma,
                bachelor = bachelor,
                postGrade = postGrad,
                doctorate = doctorateGrade
            ),
            careerDetails = CareerDetails(
                currentIndustry = currentIndustry,
                department = department,
                desiredJobRole = jobRole,
                preferredWorkShift = workShift,
                preferredWorkLocation = workLocation
            ),
            keySkill = KeySkills(
                skill = skill,
                workStatus = workStatus,
                areaOfEx = areaOfExp,
                expYear = yearExp
            ),
            document = DocumentDetails(
                resume = resumePdfLink,
                other = ""
            ),
            paymentStatus = PaymentStatus(
                status = "",
                id = "",
                date = "",
                totalPayment = ""
            )
        )

        val dataMap = data.toMap()
        userDatabaseReference.child(sharedManager.getUserUuid()).updateChildren(dataMap)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    findNavController().popBackStack()
                    showToast("Your data is uploaded")
                    progressbar.dismiss()
                } else {
                    showToast("try again")
                    progressbar.dismiss()
                }
            }.addOnFailureListener {
                showToast(it.message.toString())
                progressbar.dismiss()
            }
    }


    private fun isValidCredential(): Boolean {
        val image = binding.profileImage
        val fullName = binding.fullName
        val phone = binding.userPhone
        val gender = binding.gender
        val dob = binding.dateOfBirth
        val martialStatus = binding.maritialStatus
        val nationality = binding.selectNationality
        val language = binding.language
        val location = binding.currentAddress

        val skill = binding.skilled
        val workStatus = binding.workStatus
        val areaOfExp = binding.areaOfExperience
        val yearExp = binding.experienceInYear

        val scroll = binding.scrolle

        if (fullName.text.isEmpty()) {
            fullName.error = "Please enter full name"
            scroll.scrollTo(0, fullName.top)
            return false
        } else if (phone.text.isEmpty()) {
            phone.error = "enter phone number"
            scroll.scrollTo(0, phone.top)
            return false
        } else if (phone.text.length != 10) {
            phone.error = "enter valid phone number"
            scroll.scrollTo(1, phone.top)
            return false
        } else if (gender.text.isEmpty()) {
            showToast("select the gender")
            scroll.scrollTo(1, gender.top)
            return false
        } else if (dob.text.isEmpty()) {
            dob.error = "enter date of birth"
            scroll.scrollTo(1, dob.top)
            return false
        } else if (dob.text.length != 10) {
            showToast("select date of birth")
            scroll.scrollTo(1, dob.top)
            return false
        } else if (martialStatus.text.isEmpty()) {
            showToast("select the marital status")
            scroll.scrollTo(2, martialStatus.top)
            return false
        } else if (nationality.text.isEmpty()) {
            showToast("select nationality")
            scroll.scrollTo(2, nationality.top)
            return false
        } else if (language.text.isEmpty()) {
            showToast("select the language")
            scroll.scrollTo(0, language.bottom)
            return false
        } else if (location.text.isEmpty()) {
            location.error = "enter address"
            scroll.scrollTo(2, location.top)
            return false
        } else if (skill.text.isEmpty()) {
            skill.error = "enter your skill"
            scroll.scrollTo(3, skill.top)
            return false
        } else if (workStatus.text.isEmpty()) {
            showToast("select the work experience")
            scroll.scrollTo(3, workStatus.top)
            return false
        } else if (workStatus.text.toString() == "Experience") {
            if (areaOfExp.text.isEmpty()) {
                areaOfExp.error = "enter the area of experience"
                scroll.scrollTo(3, areaOfExp.top)
                return false
            } else if (yearExp.text.toString().toInt() > 20) {
                yearExp.error = "enter the year of experience"
                scroll.scrollTo(4, yearExp.top)
                return false
            }
        } else if (pdfUri == null) {
            showToast("Please select the resume")
            return false
        }
        return true
    }

    private fun dropDownList() {
        val genderList = listOf("Male", "Female", "Transgender")
        val maritalStatusList = listOf("Married", "Unmarried")
        val languageList = listOf("Hindi", "English")
        val workStatusList = listOf("Fresher", "Experience")
        val preferredWorkList = listOf("Part Time", "Full Time")
        val yesORnoList = listOf("Yes", "No")
        val yesOrNoYet = listOf("Yes", "No", "Pursuing")
        val yearOfEx = listOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12")
        val lastEducationList = listOf("10th", "12th", "Diploma", "Bachelor", "Masters")


        val languageAdapter = ArrayAdapter(requireContext(), R.layout.category_list, languageList)
        binding.language.setAdapter(languageAdapter)

        val maritalAdapter = ArrayAdapter(requireContext(), R.layout.category_list, maritalStatusList)
        binding.maritialStatus.setAdapter(maritalAdapter)

        val genderAdapter = ArrayAdapter(requireContext(), R.layout.category_list, genderList)
        binding.gender.setAdapter(genderAdapter)

        val workStatusAdapter = ArrayAdapter(requireContext(), R.layout.category_list, workStatusList)
        binding.workStatus.setAdapter(workStatusAdapter)

        val nationalityAdapter = ArrayAdapter(requireContext(), R.layout.category_list, countries)
        binding.selectNationality.setAdapter(nationalityAdapter)

        val departmentAdapter = ArrayAdapter(requireContext(), R.layout.category_list, departmentList)
        binding.currentDepartment.setAdapter(departmentAdapter)

        val preferredWorkAdapter = ArrayAdapter(requireContext(), R.layout.category_list, preferredWorkList)
        binding.workShift.setAdapter(preferredWorkAdapter)

        val preferredLocationAdapter = ArrayAdapter(requireContext(), R.layout.category_list, StateAndDistrict.states)
        binding.prefferedWorkLocation.setAdapter(preferredLocationAdapter)

        val secondarySchoolAdapter = ArrayAdapter(requireContext(), R.layout.category_list, yesORnoList)
        binding.secondarySchool.setAdapter(secondarySchoolAdapter)

        val higherSecondarySchool = ArrayAdapter(requireContext(), R.layout.category_list, yesORnoList)
        binding.higherSecondarySchool.setAdapter(higherSecondarySchool)

        val diplomaAdapter = ArrayAdapter(requireContext(), R.layout.category_list, yesORnoList)
        binding.diploma.setAdapter(diplomaAdapter)

        val bachelorAdapter = ArrayAdapter(requireContext(), R.layout.category_list, yesOrNoYet)
        binding.bachelors.setAdapter(bachelorAdapter)

        val postGraduationAdapter = ArrayAdapter(requireContext(), R.layout.category_list, yesOrNoYet)
        binding.postGraduation.setAdapter(postGraduationAdapter)

        val doctorateAdapter = ArrayAdapter(requireContext(), R.layout.category_list, yesOrNoYet)
        binding.doctorate.setAdapter(doctorateAdapter)

        val desiredJobRoleAdapter = ArrayAdapter(requireContext(), R.layout.category_list, desiredJobRole)
        binding.desiredJobRole.setAdapter(desiredJobRoleAdapter)

        val areaOfExperience = ArrayAdapter(requireContext(), R.layout.category_list, desiredJobRole)
        binding.areaOfExperience.setAdapter(areaOfExperience)

        val yearOfExperience = ArrayAdapter(requireContext(), R.layout.category_list, yearOfEx)
        binding.experienceInYear.setAdapter(yearOfExperience)

        val currentIndustryAdapter = ArrayAdapter(requireContext(), R.layout.category_list, companyList)
        binding.currentIndustry.setAdapter(currentIndustryAdapter)

        val lastEducation = ArrayAdapter(requireContext(), R.layout.category_list, lastEducationList)
        binding.lastEducationDetails.setAdapter(lastEducation)
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_PDF_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            pdfUri = data.data
            binding.resumefilename.visibility = View.VISIBLE
            val fileName = data.data!!.getFileName(requireActivity())
            binding.resumefilename.text = fileName
        }
    }


    private fun uploadResume(pdfUri: Uri?, fileName: String, pdfUrl: (String) -> Unit) {
        val storageRef = FirebaseStorage.getInstance().reference
        val pdfRef = storageRef.child("$fileName${System.currentTimeMillis()}_resume.pdf")
        progressbar.show()
        if (pdfUri != null) {
            pdfRef.putFile(pdfUri).addOnSuccessListener { taskSnapshot ->
                taskSnapshot.storage.downloadUrl.addOnSuccessListener { pdfUrl ->
                    pdfUrl(pdfUrl.toString())
                }
                progressbar.dismiss()
            }.addOnFailureListener { exception ->
                showToast(exception.message.toString())
                progressbar.dismiss()
            }
        }
    }

    /*for image*/
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                imageUri = result.data?.data!!
                binding.profileImage.setImageURI(imageUri)
            }
        }


    private fun selectImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImage.launch(intent)
    }

    private fun uploadImage(imageUri: Uri, fileName: String, imageUrlCallback: (String) -> Unit) {
        val storageRef = FirebaseStorage.getInstance().reference
        try {
            val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(requireContext().contentResolver, imageUri)
                ImageDecoder.decodeBitmap(source)
            } else {
                MediaStore.Images.Media.getBitmap(requireContext().contentResolver, imageUri)
            }
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos)
            val imageData = baos.toByteArray()
            progressbar.show()

            // Use a unique name for the image file
            val uniqueFileName = "${UUID.randomUUID()}_profileImage.jpg"
            val profileRef = storageRef.child("$fileName/$uniqueFileName")

            profileRef.putBytes(imageData).addOnSuccessListener { taskSnapshot ->
                // Image uploaded successfully, get the download URL
                profileRef.downloadUrl.addOnSuccessListener { uri ->
                    imageUrlCallback(uri.toString())
                    progressbar.dismiss()
                }.addOnFailureListener { exception ->
                    showToast("Failed to get download URL")
                    Log.e("FirebaseStorage", "Failed to get download URL", exception)
                    progressbar.dismiss()
                }
            }.addOnFailureListener { exception ->
                showToast("Failed to upload image")
                Log.e("FirebaseStorage", "Failed to upload image", exception)
                progressbar.dismiss()
            }

        } catch (e: IOException) {
            showToast("Failed to process image")
            Log.e("FirebaseStorage", "Failed to process image", e)
            progressbar.dismiss()
        }
    }

    private fun setUpProgressDialog() {
        progressbar = ProgressDialog(requireContext())
        progressbar.setMessage("Loading...")
        progressbar.setCancelable(false)
        progressbar.create()
    }

    private fun getLocation(callback: (latitude: String, longitude: String) -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            showPermissionRationale()
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    latitude = location.latitude.toString()
                    longitude = location.longitude.toString()
                    callback.invoke(location.latitude.toString(), location.longitude.toString())
                }
            }
            .addOnFailureListener { e ->
                requireContext().showToast(e.message.toString())
            }
    }

    private fun showPermissionRationale() {
        requireContext().showAlert(
            "Location Permission Required",
            "We need your location to provide you with relevant information.",
            onOkayClick = {
                requestPermissionLauncher.launch(locationPermission)
            },
            onNoClick = {
                requestPermissionLauncher.launch(locationPermission)
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}