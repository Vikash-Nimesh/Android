package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Parameters(
    val num_pages: Int?,
    val page: Int?,
    val query: String?
):Parcelable