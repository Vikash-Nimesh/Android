package com.example.aajivikasetu.screen.fragment.main.maindash

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentBloodDonationBinding
import com.example.aajivikasetu.model.blooddonar.BloodDonorData
import com.example.aajivikasetu.model.blooddonar.Geo
import com.example.aajivikasetu.screen.fragment.main.state.BloodDonorViewModel
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.StateAndDistrict
import com.example.aajivikasetu.utils.showAlert
import com.example.aajivikasetu.utils.showToast
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlin.math.log

@AndroidEntryPoint
class BloodDonationFragment : Fragment() {
    private var _binding: FragmentBloodDonationBinding? = null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    lateinit var sharedManager: SharedManager

    private var latitude: String? = null
    private var longitude: String? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val locationPermission = Manifest.permission.ACCESS_FINE_LOCATION

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                getLocation{ _, _ ->

                }
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), locationPermission)
                ) {
                    showPermissionRationale()
                }
            }
        }

    private val bloodDonorViewModel by viewModels<BloodDonorViewModel>()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentBloodDonationBinding.inflate(inflater, container, false)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                locationPermission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            getLocation{ latitude: String, longitude: String ->
                this.latitude = latitude
                this.longitude = longitude
                Log.d("datacomss", "$latitude $longitude")
            }
        } else {
            requestPermissionLauncher.launch(locationPermission)
        }

        val state = StateAndDistrict.states
        val bloodGroup = StateAndDistrict.bloodGroups
        val name = sharedManager.getName()
        val email = sharedManager.getEmailId()
        val phone = sharedManager.getUserPhoneNumber()


        binding.userName.setText(name)
        binding.userEmail.setText(email)
        binding.userPhone.setText(phone)

        val bloodAdapter = ArrayAdapter(requireContext(), R.layout.category_list, bloodGroup)
        binding.bloodGroup.setAdapter(bloodAdapter)


        val stateAdapter = ArrayAdapter(requireContext(), R.layout.category_list, state)
        binding.state.setAdapter(stateAdapter)

        var selectedDistrict: String? = null
        binding.state.setOnItemClickListener { _, _, position, _ ->
            val selectedState = stateAdapter.getItem(position).toString()
            val districtList = StateAndDistrict.initializeTheDistrict(selectedState)

            if (districtList != null) {
                val districtAdapter =
                    ArrayAdapter(requireContext(), R.layout.category_list, districtList)
                binding.district.setAdapter(districtAdapter)

                // Restore the selected district if available
                if (selectedDistrict != null && districtList.contains(selectedDistrict)) {
                    val districtPosition = districtList.indexOf(selectedDistrict)
                    binding.district.setText(selectedDistrict, false)
                    binding.district.setSelection(districtPosition)
                } else {
                    binding.district.setText("", false)
                }
            }
        }

        // Set a listener for state selection
        /*binding.state.setOnItemClickListener { _, _, position, _ ->
            val selectedState = stateAdapter.getItem(position).toString()
            val districtList = stateOfDistrict[selectedState]
            // Update the district adapter with the new list
            if (districtList != null) {
                val districtAdapter = ArrayAdapter(requireContext(), R.layout.category_list, districtList)
                binding.district.setAdapter(districtAdapter)
            }
        }*/

        binding.submitButton.setOnClickListener {
            if (isValidDetails()) {
                dataPushInDatabase()
            }
        }


        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }

        return binding.root
    }

    private fun getLocation(callback: (latitude: String, longitude: String) -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            showPermissionRationale()
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    latitude = location.latitude.toString()
                    longitude = location.longitude.toString()
                    callback.invoke(location.latitude.toString(), location.longitude.toString())
                }
            }
            .addOnFailureListener { e ->
                requireContext().showToast(e.message.toString())
            }
    }

    private fun showPermissionRationale() {
        requireContext().showAlert(
            "Location Permission Required",
            "We need your location to provide you with relevant information.",
            onOkayClick = {
                requestPermissionLauncher.launch(locationPermission)
            },
            onNoClick = {
                requestPermissionLauncher.launch(locationPermission)
            }
        )
    }

    private fun dataPushInDatabase() {
        val name = binding.userName.text.toString()
        val phone = binding.userPhone.text.toString()
        val email = binding.userEmail.text.toString()
        val bloodGroup = binding.bloodGroup.text.toString()
        val state = binding.state.text.toString()
        val district = binding.district.text.toString()
        val city = binding.cityName.text.toString()


        if (latitude != null && longitude != null){
            val data = BloodDonorData(name, phone, email, bloodGroup, state, district, city, Geo(latitude.toString(), longitude.toString()))
            bloodDonorViewModel.addBloodData(data, sharedManager.getUserUuid())
            bloodDonorViewModel.bloodDetails.observe(viewLifecycleOwner) {
                when (it) {
                    is ResultState.Loading -> {
                        binding.progeress.visibility = View.VISIBLE
                    }

                    is ResultState.Success -> {
                        binding.progeress.visibility = View.GONE
                        showToast(it.data.toString())
                        findNavController().popBackStack()
                    }

                    is ResultState.Error -> {
                        showToast(it.message.toString())
                        binding.progeress.visibility = View.GONE
                    }
                }
            }
        }else{
            requireContext().showToast("Provide location permission")
        }

    }

    private fun isValidDetails(): Boolean {
        val name = binding.userName
        val email = binding.userEmail
        val phone = binding.userPhone
        val city = binding.cityName
        if (name.text.isEmpty()) {
            name.error = "Please write the name"
            return false
        } else if (email.text.isEmpty()) {
            email.error = "please enter the email"
            return false
        } else if (phone.text.isEmpty()) {
            phone.error = "enter phone number"
            return false
        } else if (phone.text.length != 10) {
            phone.error = "enter valid phone number"
            return false
        } else if (!phone.text.startsWith("6") && !phone.text.startsWith("7") &&
            !phone.text.startsWith("8") && !phone.text.startsWith("9")
        ) {
            phone.error = "enter correct number"
            return false
        } else if (binding.bloodGroup.text.isEmpty()) {
            showToast("please select blood group")
            return false
        } else if (binding.state.text.isEmpty()) {
            showToast("please select the state")
            return false
        } else if (binding.district.text.isEmpty()) {
            showToast("please select the district")
            return false
        } else if (city.text.isEmpty()) {
            city.error = "please enter the city"
        }
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}