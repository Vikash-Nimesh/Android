package com.example.aajivikasetu.model

data class AdminModelData(
    var name : String = "",
    val email : String = "",
    var image : String = "",
    var phone : String = "",
    val uuid : String = "",
    var password : String = ""
)