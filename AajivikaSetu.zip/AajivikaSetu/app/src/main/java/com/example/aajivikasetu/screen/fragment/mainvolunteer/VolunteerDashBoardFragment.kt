package com.example.aajivikasetu.screen.fragment.mainvolunteer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentVolunteerDashBoardBinding
import com.example.aajivikasetu.databinding.FragmentVolunteerForgetPasswordBinding
import com.example.aajivikasetu.sharedpref.SharedManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class VolunteerDashBoardFragment : Fragment() {
    private var _binding : FragmentVolunteerDashBoardBinding ?= null
    private val binding : FragmentVolunteerDashBoardBinding by lazy { requireNotNull(_binding) }

    @Inject
    lateinit var sharedManager: SharedManager
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentVolunteerDashBoardBinding.inflate(inflater, container, false)





        return binding.root
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}