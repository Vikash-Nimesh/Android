package com.example.aajivikasetu.utils

import android.annotation.SuppressLint
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.MotionEvent
import android.widget.EditText
import com.example.aajivikasetu.R

object Utility {
    @SuppressLint("ClickableViewAccessibility")
    fun passwordVisible(userPassword: EditText) {
        var passwordVisible = false
        userPassword.setOnTouchListener { _, event ->
            val right = 2
            if (event.getAction() === MotionEvent.ACTION_UP) {
                if (event.rawX >= userPassword.right - userPassword.compoundDrawables[right].bounds.width()) {
                    val selection: Int = userPassword.selectionEnd
                    //Handles Multiple option popups
                    if (passwordVisible) {
                        //set drawable image here
                        userPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.view_off, 0)
                        //for hide password
                        userPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                        passwordVisible = false
                    } else {
                        //set drawable image here
                        userPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.view_password, 0)
                        //for show password
                        userPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                        passwordVisible = true
                    }
                    userPassword.isLongClickable = false //Handles Multiple option popups
                    userPassword.setSelection(selection)
                    return@setOnTouchListener true
                }
            }
            false
        }
    }
}