package com.example.aajivikasetu.di

import android.content.Context
import android.content.SharedPreferences
import com.example.aajivikasetu.network.JobService
import com.example.aajivikasetu.repo.Repository
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.Constants
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object Module {

    @Provides
    @Singleton
    fun getContext(@ApplicationContext context: Context) : Context{
        return context
    }

    @Provides
    @Singleton
    fun getSharedPreferences(context: Context) : SharedPreferences{
        return context.getSharedPreferences(Constants.Local_Data, Context.MODE_PRIVATE)
    }

    @Provides
    @Singleton
    fun getSharedManager(sharedPreferences: SharedPreferences) : SharedManager{
        return SharedManager(sharedPreferences)
    }

    /*--------------------------------------------------------------------------------------*/

    @Singleton
    @Provides
    @UserModel
    fun getUserModelDatabaseReference() : DatabaseReference{
        return FirebaseDatabase.getInstance().getReference(Constants.UserModel)
    }

    @Singleton
    @Provides
    @BloodDetails
    fun bloodDetailsDatabaseReference() : DatabaseReference{
        return FirebaseDatabase.getInstance().getReference(Constants.BloodDetails)
    }

    @Singleton
    @Provides
    @LoneRequest
    fun loneRequestDatabaseReference() : DatabaseReference{
        return FirebaseDatabase.getInstance().getReference(Constants.LoneRequest)
    }


    @Singleton
    @Provides
    @AdminModel
    fun getAdminModelDatabaseReference() : DatabaseReference{
        return FirebaseDatabase.getInstance().getReference(Constants.AdminModel)
    }

    @Singleton
    @Provides
    @VolunteerModel
    fun getVolunteerModelDatabaseReference() : DatabaseReference{
        return FirebaseDatabase.getInstance().getReference(Constants.VolunteerModel)
    }

    @Provides
    @Singleton
    fun getRespository(
        @UserModel databaseReference: DatabaseReference,
        @BloodDetails bloodDetailsDatabaseReference: DatabaseReference,
        @LoneRequest loneRequestDatabaseReference: DatabaseReference
    ) : Repository{
        return Repository(databaseReference, bloodDetailsDatabaseReference, loneRequestDatabaseReference)
    }


    /*-----------------------------------------------------------------------------------------------------------*/

    @Provides
    @Singleton
    fun getApiReference() : Retrofit{
        return Retrofit
            .Builder()
            .baseUrl(Constants.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun getJobServicesReference(retrofit: Retrofit) : JobService{
        return retrofit.create(JobService::class.java)
    }
}