package com.example.aajivikasetu.screen.fragment.mainadmin.state

import android.annotation.SuppressLint
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.example.aajivikasetu.databinding.FragmentLoanRequestDataBinding
import com.example.aajivikasetu.databinding.LoanRequestDataBinding
import com.example.aajivikasetu.model.lonedata.LoneRequestDataModel
import com.example.aajivikasetu.utils.formateDate

class LoanRequestAdapter(private val loneRequest : List<LoneRequestDataModel>) : RecyclerView.Adapter<LoanRequestAdapter.LoanRequestVH>(){
    class LoanRequestVH (val loanRequestDataBinding: LoanRequestDataBinding) : RecyclerView.ViewHolder(loanRequestDataBinding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LoanRequestVH {
        return LoanRequestVH(LoanRequestDataBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return loneRequest.size
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LoanRequestVH, position: Int) {
        val data = loneRequest[position]
        holder.loanRequestDataBinding.apply {
            this.nameLoanUser.text = "Name: ${data.name}"
            this.phoneUser.text = "Phone: ${data.phone}"
            this.email.text = "Email: ${data.email}"
            this.loneAmount.text = "Amount: ${data.amount}"
            this.requestedDate.text = "Date: ${data.requestDate}"
            this.address.text = "Address: ${data.address?.localAdd}, ${data.address?.city}, ${data.address?.district}, ${data.address?.state}"
        }
    }
}