package com.example.aajivikasetu.model.blooddonar

data class BloodDonorData(
    var name : String = "",
    val phoneNo : String = "",
    val email : String = "",
    val bloodGroup : String = "",
    val state : String = "",
    val district : String = "",
    val city : String = "",
    var geo : Geo ?= null
)


data class Geo(
    var lat : String = "",
    var log : String = ""
)