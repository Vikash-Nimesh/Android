package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class JobDataModel(
    val `data`: List<Data>,
    val parameters: Parameters,
    val request_id: String?,
    val status: String?
):Parcelable