package com.example.aajivikasetu.network

import com.example.aajivikasetu.model.jobdata.JobDataModel
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
// aman - 9bcef8e760msh8cbedf04c015752p1dce9djsn01c3ac4a26e7
// gaddar - 212f78f422msh67e211916a160e4p162fd8jsnec18a2c3c84c
interface JobService {
    @GET("search")
    suspend fun getJobData(
        @Query("query") query: String,
        @Query("page") page: Int,
        @Query("num_pages") numPages: Int,
        @Header("x-rapidapi-key") header: String = "724c7fbf07mshf638f30a69f24fcp119d94jsna7f7d10b3d67",
        @Header("x-rapidapi-host") head : String = "jsearch.p.rapidapi.com"
    ) : JobDataModel
}