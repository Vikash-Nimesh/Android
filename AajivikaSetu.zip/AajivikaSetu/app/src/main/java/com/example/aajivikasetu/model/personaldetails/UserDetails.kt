package com.example.aajivikasetu.model.personaldetails

data class UserDetails(
    var name : String = "",
    var email : String = "",
    var uuid : String = "",
    var password : String = "",
    var personalDetails : PersonalDetails ?= null,
    var educationDetails : EducationDetails ?= null,
    var careerDetails : CareerDetails ?= null,
    var keySkill : KeySkills ?= null,
    var document : DocumentDetails ?= null,
    var paymentStatus: PaymentStatus ?= null
)