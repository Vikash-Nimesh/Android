package com.example.aajivikasetu.screen.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.ActivityDashBoardBinding

class DashBoardActivity : AppCompatActivity() {
    private lateinit var binding : ActivityDashBoardBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashBoardBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}