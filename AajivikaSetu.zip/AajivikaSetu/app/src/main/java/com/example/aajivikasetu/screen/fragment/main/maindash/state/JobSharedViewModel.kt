package com.example.aajivikasetu.screen.fragment.main.maindash.state

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.aajivikasetu.model.jobdata.Data

class JobSharedViewModel : ViewModel() {
    private val _selectedJob = MutableLiveData<Data>()
    val getJob: LiveData<Data> get() = _selectedJob

    fun selectJob(job: Data) {
        _selectedJob.value = job
    }
}