package com.example.aajivikasetu.screen.fragment.mainadmin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentAdminDashBoardBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AdminDashBoardFragment : Fragment() {
    private var _binding : FragmentAdminDashBoardBinding ?= null
    private val binding : FragmentAdminDashBoardBinding by lazy { requireNotNull(_binding) }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentAdminDashBoardBinding.inflate(inflater, container, false)

        binding.bloodRequestButton.setOnClickListener {
            findNavController().navigate(R.id.action_adminDashBoardFragment_to_bloodDonarDataFragment)
        }
        binding.requestLoanButton.setOnClickListener {
            findNavController().navigate(R.id.action_adminDashBoardFragment_to_loanRequestDataFragment)
        }
        binding.createButton.setOnClickListener {
            findNavController().navigate(R.id.action_adminDashBoardFragment_to_createVolunteerFragment)
        }
        binding.confirmPaymentButton.setOnClickListener {
            findNavController().navigate(R.id.action_adminDashBoardFragment_to_paymentPendingStatusFragment)
        }

        return binding.root
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}