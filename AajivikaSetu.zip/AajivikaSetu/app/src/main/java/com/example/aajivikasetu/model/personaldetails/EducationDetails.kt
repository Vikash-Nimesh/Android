package com.example.aajivikasetu.model.personaldetails

data class EducationDetails(
    var secondarySchool : String = "",
    var higherSecondarySchool : String = "",
    var diploma : String = "",
    var bachelor : String = "",
    var postGrade : String = "",
    var doctorate : String = ""
)