package com.example.aajivikasetu.screen.fragment.auth.user

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentForgetPasswordBinding
import com.example.aajivikasetu.di.UserModel
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.FacebookAuthenticationHelper
import com.example.aajivikasetu.utils.ProgressBarDialog
import com.example.aajivikasetu.utils.Utility
import com.example.aajivikasetu.utils.hashPassword
import com.example.aajivikasetu.utils.isInternetAvailable
import com.example.aajivikasetu.utils.isValidEmail
import com.facebook.CallbackManager
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class UserForgetPasswordFragment : Fragment() {
    private var _binding: FragmentForgetPasswordBinding? = null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    @UserModel
    lateinit var databaseReference: DatabaseReference

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var progressBar: ProgressBarDialog
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentForgetPasswordBinding.inflate(inflater, container, false)

        progressBar = ProgressBarDialog(requireActivity())

        firebaseAuth = FirebaseAuth.getInstance()

        binding.updatePassword.setOnClickListener {
            if (isInternetAvailable(requireContext())){
                if (isValidCredential()){
                    updatePassword()
                }
            }else{
                showMessage("check your internet connection")
            }
        }

        binding.arrowBack.setOnClickListener {
            findNavController().popBackStack()
        }
        /*binding.openGmail.visibility = View.VISIBLE
        binding.openGmail.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setClassName("com.google.android.gm", "com.google.android.gm.ConversationListActivityGmail")
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                showMessage("Gmail App not found")
            }
        }*/

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Utility.passwordVisible(binding.oldPassword)
        Utility.passwordVisible(binding.newPassword)
    }

    private fun updatePassword() {
        val email = binding.forgerEmail.text.toString().trim()
        val oldPassword = binding.oldPassword.text.toString()
        val newPassword = binding.newPassword.text.toString()


        val query = databaseReference.orderByChild("email").equalTo(email)
        progressBar.startDialog()

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    sendEmailVerification(email, oldPassword, newPassword, snapshot)
                    progressBar.isDismiss()
                }else{
                    showMessage("email is not registered, please Sign In")
                    progressBar.isDismiss()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                showMessage(error.message)
                progressBar.isDismiss()
            }
        })
    }

    private fun sendEmailVerification(email: String, oldPassword: String, newPassword: String, snapshot: DataSnapshot) {
        firebaseAuth.signInWithEmailAndPassword(email, oldPassword).addOnCompleteListener {
            val firebaseUser = firebaseAuth.currentUser
            if (it.isSuccessful){
                firebaseUser?.sendEmailVerification()
                if (firebaseUser!!.isEmailVerified){
                    firebaseUser.updatePassword(newPassword)
                    progressBar.startDialog()
                    for (snapUser in snapshot.children){
                        val userKey = snapUser.key
                        val userRef = databaseReference.child(userKey!!)
                        userRef.child("password").setValue(hashPassword(newPassword)).addOnCompleteListener { task ->
                            if (task.isSuccessful){
                                findNavController().navigate(R.id.action_forgetPasswordFragment_to_userLogInFragment)
                                findNavController().popBackStack(R.id.forgetPasswordFragment, inclusive = true)
                                showMessage("Password update")
                                binding.forgerEmail.text.clear()
                                binding.oldPassword.text.clear()
                                binding.newPassword.text.clear()
                                progressBar.isDismiss()
                            } else {
                                progressBar.isDismiss()
                                showMessage("Failed to update password")
                            }
                        }
                    }
                }else{
                    //binding.openGmail.visibility = View.VISIBLE
                    showMessage("Please verify your email")
                }
            }else{
                showMessage("your old password is wrong")
            }
        }


    }


    private fun isValidCredential(): Boolean {
        if (binding.forgerEmail.text.toString().isEmpty()){
            binding.forgerEmail.error = "Please enter the email"
            return false
        }else if(!isValidEmail(binding.forgerEmail.text.toString())){
            binding.forgerEmail.error = "please enter valid email"
            return false
        }else if (binding.oldPassword.text.toString().isEmpty()){
            binding.oldPassword.error = "Please enter the old password"
            return false
        }else if (binding.oldPassword.text.toString().length < 6){
            binding.oldPassword.error = "Password should be greater then 6 characters"
            return false
        }else if (binding.newPassword.text.toString().isEmpty()){
            binding.newPassword.error = "Please enter the old password"
            return false
        }else if (binding.newPassword.text.toString().length < 6){
            binding.newPassword.error = "Password should be greater then 6 characters"
            return false
        }
        return true
    }

    private fun showMessage(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}