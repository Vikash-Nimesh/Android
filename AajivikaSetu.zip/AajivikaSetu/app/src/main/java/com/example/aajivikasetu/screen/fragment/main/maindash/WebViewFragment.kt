package com.example.aajivikasetu.screen.fragment.main.maindash

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentWebViewBinding


class WebViewFragment : Fragment() {
    private var _binding : FragmentWebViewBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentWebViewBinding.inflate(inflater, container, false)

        val url = arguments?.getString("OfficialLink")
        if (url != null){
            binding.webView.loadUrl(url)
            binding.webView.webViewClient = MyWebViewClient()
        }


        return binding.root
    }

    inner class MyWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            return false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}