package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class JobRequiredExperience(
    val experience_mentioned: Boolean,
    val experience_preferred: Boolean,
    val no_experience_required: Boolean,
    val required_experience_in_months: Int?
):Parcelable