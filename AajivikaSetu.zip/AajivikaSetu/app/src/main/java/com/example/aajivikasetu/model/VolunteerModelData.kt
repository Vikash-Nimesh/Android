package com.example.aajivikasetu.model

data class VolunteerModelData(
    var name : String = "",
    val email : String = "",
    var phone : String = "",
    var image : String = "",
    val uuid : String = "",
    var password : String = "",
    var referenceId : String = "",
    var totalCount : Int = 0
)