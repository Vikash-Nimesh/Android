package com.example.aajivikasetu.screen.fragment.splash

import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentSplashBinding
import com.example.aajivikasetu.sharedpref.SharedManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SplashFragment : Fragment() {
    private var _binding: FragmentSplashBinding? = null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    lateinit var sharedManager: SharedManager
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentSplashBinding.inflate(inflater, container, false)

        Handler().postDelayed({
            if (!sharedManager.isAuthPassed()) {
                findNavController().navigate(
                    R.id.mainLogInFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.splashFragment, true).build()
                )
            } else if (!sharedManager.isPermissionPassed()) {
                findNavController().navigate(
                    R.id.permissionFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.splashFragment, true).build()
                )
            } else if (sharedManager.isUserLogIn()) {
                findNavController().navigate(
                    R.id.dashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.splashFragment, true).build()
                )
            } else if(sharedManager.isAdminLogIn()){
                findNavController().navigate(
                    R.id.adminDashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.splashFragment, true).build()
                )
            } else {
                findNavController().navigate(
                    R.id.volunteerDashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.splashFragment, true).build()
                )
            }
        }, 500)


        return binding.root
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}