package com.example.aajivikasetu.screen.fragment.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentPostJobBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PostJobFragment : Fragment() {
    private var _binding : FragmentPostJobBinding ?= null
    private val binding : FragmentPostJobBinding by lazy {  requireNotNull(_binding) }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentPostJobBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}