package com.example.aajivikasetu.screen.fragment.main.maindash

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentJobDescriptionBinding
import com.example.aajivikasetu.model.jobdata.Data
import com.example.aajivikasetu.screen.fragment.main.maindash.state.ApplyOptionAdapter
import com.example.aajivikasetu.screen.fragment.main.maindash.state.JobSharedViewModel
import com.example.aajivikasetu.utils.isPackageInstalled


class JobDescriptionFragment : Fragment() {
    private var _binding : FragmentJobDescriptionBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    private val jobSharedViewModel : JobSharedViewModel by activityViewModels()
    private lateinit var applyOptionAdapter: ApplyOptionAdapter
    private lateinit var data: Data
    private var package_name = "com.android.chrome"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentJobDescriptionBinding.inflate(inflater, container, false)

        jobSharedViewModel.getJob.observe(viewLifecycleOwner) { currentDataJob ->
            setData(currentDataJob)
            data = currentDataJob
        }



        return binding.root
    }

    @SuppressLint("SetTextI18n")
    private fun setData(currentDataJob: Data?) {
        if (currentDataJob != null){
            binding.apply {
                jobTitile.text = currentDataJob.job_title
                jobDes.text = currentDataJob.job_description
                Glide.with(requireContext()).load(currentDataJob.employer_logo).into(companyLogo)
                companyName.text = currentDataJob.employer_name
                companyLocation.text = currentDataJob.job_city + "( ${currentDataJob.job_employment_type})"

                applyOptionAdapter = ApplyOptionAdapter(currentDataJob.apply_options)
                binding.applyOptionRv.adapter = applyOptionAdapter
                binding.applyOptionRv.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            }

            binding.officialCompanyLink.setOnClickListener {
                /*val bundle = Bundle()
                bundle.putString("OfficialLink", currentDataJob.employer_website)
                findNavController().navigate(R.id.action_jobDescriptionFragment_to_webViewFragment, bundle)
                currentDataJob.employer_website?.let { it1 -> openWebPage(it1) }*/
                Log.d("datalinkk",currentDataJob.employer_website.toString())
                if (currentDataJob.employer_website != null){
                    openCustomTab(requireActivity(), Uri.parse(currentDataJob.employer_website))
                }
            }

            applyOptionAdapter.applyButton(object : ApplyOptionAdapter.OnApplyButtonClick {
                override fun onApplyButton(applyLink: String?) {
                    /*val bundle = Bundle()
                    bundle.putString("OfficialLink", applyLink)
                    findNavController().navigate(R.id.action_jobDescriptionFragment_to_webViewFragment, bundle)
                    Log.d("datalinkk",applyLink.toString())
                    if (applyLink != null) {
                        openWebPage(applyLink)
                    }*/
                    /*if (applyLink != null) {
                        openWebPage(applyLink)
                    }*/


                    openCustomTab(requireActivity(), Uri.parse(applyLink))
                }
            })
        }
    }

    fun openCustomTab(activity: Activity, uri: Uri?) {
        val packageName = "com.android.chrome"
        try {
            val customIntent = CustomTabsIntent.Builder()
            val params = CustomTabColorSchemeParams.Builder()
            customIntent.setToolbarColor(ContextCompat.getColor(requireContext(), R.color.white))
            customIntent.setDefaultColorSchemeParams(params.build())
            customIntent.setShowTitle(true)
            customIntent.setShareState(CustomTabsIntent.SHARE_STATE_ON)
            customIntent.setInstantAppsEnabled(true)

            val customBuilder = customIntent.build()
            customBuilder.intent.setPackage(packageName)
            customBuilder.launchUrl(activity, uri!!)
        }catch (e : Exception){
            Toast.makeText(requireContext(), "something went to wrong", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun openWebPage(url: String) {
        val builder = CustomTabsIntent.Builder()
        val params = CustomTabColorSchemeParams.Builder()
        params.setToolbarColor(ContextCompat.getColor(requireContext(), R.color.white))
        builder.setDefaultColorSchemeParams(params.build())
        builder.setShowTitle(true)
        builder.setShareState(CustomTabsIntent.SHARE_STATE_ON)
        builder.setInstantAppsEnabled(true)
        val customBuilder = builder.build()

        if (requireContext().isPackageInstalled()) {
            customBuilder.intent.setPackage(package_name)
            customBuilder.launchUrl(requireContext(), Uri.parse(url))
        } else {
            Toast.makeText(requireContext(), "Please download the chrome", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("market://details?id=$package_name")
            startActivity(intent)
        }
    }
}