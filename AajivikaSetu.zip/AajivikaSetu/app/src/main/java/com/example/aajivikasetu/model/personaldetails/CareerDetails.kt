package com.example.aajivikasetu.model.personaldetails

data class CareerDetails(
    var currentIndustry : String = "",
    var department : String = "",
    var desiredJobRole : String = "",
    var preferredWorkShift : String = "",
    var preferredWorkLocation : String = ""
)