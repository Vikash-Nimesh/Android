package com.example.aajivikasetu.screen.fragment.auth.user

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentSignUpBinding
import com.example.aajivikasetu.di.UserModel
import com.example.aajivikasetu.model.personaldetails.CareerDetails
import com.example.aajivikasetu.model.personaldetails.DocumentDetails
import com.example.aajivikasetu.model.personaldetails.EducationDetails
import com.example.aajivikasetu.model.personaldetails.KeySkills
import com.example.aajivikasetu.model.personaldetails.PaymentStatus
import com.example.aajivikasetu.model.personaldetails.PersonalDetails
import com.example.aajivikasetu.model.personaldetails.UserDetails
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.FacebookAuthenticationHelper
import com.example.aajivikasetu.utils.ProgressBarDialog
import com.example.aajivikasetu.utils.Utility
import com.example.aajivikasetu.utils.hashPassword
import com.example.aajivikasetu.utils.isInternetAvailable
import com.example.aajivikasetu.utils.isValidEmail
import com.facebook.CallbackManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class UserSignUpFragment : Fragment() {
    private var _binding: FragmentSignUpBinding? = null
    private val binding by lazy { requireNotNull(_binding) }

    private lateinit var firebaseAuth: FirebaseAuth

    @Inject
    @UserModel
    lateinit var databaseReference: DatabaseReference

    @Inject
    lateinit var sharedManager: SharedManager

    private val RC_SIGN_IN: Int = 1
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var mGoogleSignInOptions: GoogleSignInOptions

    private lateinit var progressBar: ProgressBarDialog

    private lateinit var callbackManager: CallbackManager
    private lateinit var facebookAuthenticationHelper: FacebookAuthenticationHelper

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSignUpBinding.inflate(inflater, container, false)

        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }

        progressBar = ProgressBarDialog(requireActivity())

        firebaseAuth = FirebaseAuth.getInstance()
        callbackManager = CallbackManager.Factory.create()
        facebookAuthenticationHelper = FacebookAuthenticationHelper(this, callbackManager)

        binding.signUp.setOnClickListener {
            if (validDetails()) {
                resisteredUser()
            }
        }

        binding.arrowBack.setOnClickListener {
            findNavController().popBackStack()
        }


        binding.signwithgoogle.setOnClickListener {
            onGoogleClick()
        }

        configureGoogleSignIn()

        // for facebook login
        binding.signwithfacebook.setOnClickListener {
            progressBar.startDialog()
            facebookAuthenticationHelper.performLogin({ userId: String, name: String, email: String?, imageUrl: String ->
                updateUiFormFaceBook(userId, name, email, imageUrl)
                progressBar.isDismiss()
            }, onCancel = {
                showMessage("cancel")
                progressBar.isDismiss()
            }, onError = {
                showMessage(it)
                progressBar.isDismiss()
            })
            showMessage("implemented soon")
        }


        return binding.root
    }


    private fun updateUiFormFaceBook(
        userIdOfFacebook: String,
        userName: String,
        email: String?,
        imageUrl: String
    ) {
        if (email != null) {
            updateUI(userName, email, userIdOfFacebook, imageUrl)
        } else {
            Toast.makeText(requireContext(), "Please sign through google", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Utility.passwordVisible(binding.userPassword)

    }

    private fun configureGoogleSignIn() {
        mGoogleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        mGoogleSignInClient = GoogleSignIn.getClient(requireContext(), mGoogleSignInOptions)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun onGoogleClick() {
        if (isInternetAvailable(requireContext())) {
            signIn()
        } else {
            showMessage("network is not available")
        }
    }

    private fun signIn() {
        progressBar.startDialog()
        val signInIntent: Intent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        callbackManager.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                firebaseAuthWithGoogle(account)
            } catch (e: ApiException) {
                progressBar.isDismiss()
                showMessage("Google sign in failed")
            }
        }
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount?) {
        val credential = GoogleAuthProvider.getCredential(account?.idToken, null)

        firebaseAuth.signInWithCredential(credential).addOnCompleteListener {
            if (it.isSuccessful) {
                val user = firebaseAuth.currentUser
                val name = user?.displayName.toString()
                val email = user?.email.toString()
                val userImage = user?.photoUrl.toString()
                val userUuid = user?.uid.toString()

                updateUI(name, email, userUuid, userImage)
            } else {
                progressBar.isDismiss()
                showMessage("Google sign in failed:(")
            }
        }
    }

    private fun updateUI(name: String, email: String, userUuid: String, userImage: String) {

        val query = databaseReference.orderByChild("email").equalTo(email)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (userSnapShort in snapshot.children) {
                        val userData = userSnapShort.getValue(UserDetails::class.java)

                        if (userData != null) {
                            sharedManager.setUserData(userData.name, userData.email, userData.uuid)
                        }
                        if (userData?.personalDetails?.image?.length!! > 10) {
                            sharedManager.setImageUrl(userData.personalDetails?.image.toString())
                        }

                        sharedManager.addAuthData(userUuid)
                        sharedManager.userLogIn(userUuid)
                        findNavController().navigate(
                            R.id.permissionFragment,
                            null,
                            NavOptions.Builder().setPopUpTo(R.id.mainLogInFragment, true).build()
                        )
                        progressBar.isDismiss()
                    }
                } else {
                    //val userModel = UserDetails(name, email, "", userImage, userUuid, hashPassword(""), resumeDetails = ResumeDetails("", "", "", "", "", "", "", "" ,"", "", "", "", "", "", "", "", ""))
                    val userModel = UserDetails(name = name, email = email, uuid = userUuid, password = hashPassword(""),
                        personalDetails = PersonalDetails("", image = userImage, "", "", "", "", "", "", ""),
                        educationDetails = EducationDetails("","","","","",""),
                        careerDetails = CareerDetails("","","","",""),
                        keySkill = KeySkills("","","", ""),
                        document = DocumentDetails("",""),
                        paymentStatus = PaymentStatus("","","","")
                    )

                    databaseReference.child(userUuid).setValue(userModel)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                sharedManager.setUserData(name, email, userUuid)
                                sharedManager.setImageUrl(userImage)
                                sharedManager.addAuthData(userUuid)
                                sharedManager.userLogIn(userUuid)
                                findNavController().navigate(
                                    R.id.permissionFragment,
                                    null,
                                    NavOptions.Builder().setPopUpTo(R.id.mainLogInFragment, true)
                                        .build()
                                )

                                progressBar.isDismiss()
                            } else {
                                progressBar.isDismiss()
                                showMessage("failed")
                            }
                        }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.isDismiss()
                Toast.makeText(requireContext(), "Error", Toast.LENGTH_SHORT).show()
            }
        })
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun resisteredUser() {
        val name = binding.userName.text.toString().trim()
        val email = binding.userEmail.text.toString().trim()
        val password = binding.userPassword.text.toString()
        val phone = binding.userPhone.text.toString()

        if (isInternetAvailable(requireContext())) {
            progressBar.startDialog()
            firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener {
                if (it.isSuccessful) {
                    val uuid = firebaseAuth.currentUser?.uid.toString()
                    //val user = UserModelData(name, email, phone, "", uuid, hashPassword(""), resumeDetails = ResumeDetails("", "", "", "", "", "", "", "" ,"", "", "", "", "", "", "", "", ""))
                    val user = UserDetails(name, email, uuid, hashPassword(password),
                        PersonalDetails("","",phone,"","","","","",""),
                        EducationDetails("","","","","",""),
                        CareerDetails("","","","",""),
                        KeySkills("","","", ""),
                        DocumentDetails("",""),
                        PaymentStatus("","","","")
                    )

                    databaseReference.child(uuid).setValue(user).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            sharedManager.setUserData(name, email, uuid)
                            sharedManager.setPhoneNumber(phone)

                            sharedManager.addAuthData(uuid)
                            sharedManager.userLogIn(uuid)
                            findNavController().navigate(
                                R.id.permissionFragment,
                                null,
                                NavOptions.Builder().setPopUpTo(R.id.mainLogInFragment, true)
                                    .build()
                            )

                            progressBar.isDismiss()

                        } else {
                            progressBar.isDismiss()
                            showMessage("failed")
                        }
                    }
                } else {
                    val exception: Exception? = it.exception
                    if (exception is FirebaseAuthUserCollisionException) {
                        showMessage("this email is already exits, please try with another email")
                        progressBar.isDismiss()
                    } else {
                        showMessage(exception?.message.toString())
                        progressBar.isDismiss()
                    }
                }
            }.addOnFailureListener {
                showMessage("Somethings went to wrong")
                progressBar.isDismiss()
            }
        } else {
            progressBar.isDismiss()
            showMessage("No internet connection")
        }
    }

    private fun validDetails(): Boolean {
        if (binding.userName.text.toString().isEmpty()) {
            binding.userName.error = "Please enter name"
            return false
        } else if (binding.userEmail.text.toString().isEmpty()) {
            binding.userEmail.error = "please write email"
            return false
        } else if (!isValidEmail(binding.userEmail.text.toString().trim())) {
            binding.userEmail.error = "Email id not valid"
            return false
        } else if (binding.userPhone.text.toString().isEmpty()) {
            binding.userPhone.error = "Please enter phone number"
            return false
        } else if (binding.userPhone.text.length != 10) {
            binding.userPhone.error = "Please enter valid phone number"
            return false
        } else if (binding.userPassword.text.toString().isEmpty()) {
            binding.userPassword.error = "Please enter password"
            return false
        } else if (binding.userPassword.text.toString().length < 6) {
            binding.userPassword.error = "Password should be greater the 6 characters"
            return false
        }
        return true
    }


    private fun showMessage(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}