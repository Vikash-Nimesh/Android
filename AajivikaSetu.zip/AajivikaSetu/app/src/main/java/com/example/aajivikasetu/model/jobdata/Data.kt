package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Data(
    val apply_options: List<ApplyOption>,
    val employer_company_type: String? = null,
    val employer_logo: String?= null,
    val employer_name: String? = null,
    val employer_website: String? = null,
    val job_apply_is_direct: Boolean,
    val job_apply_link: String? = null,
    val job_apply_quality_score: Double,
    val job_city: String? = null,
    val job_country: String? = null,
    val job_description: String? = null,
    val job_employment_type: String? = null,
    val job_experience_in_place_of_education: Boolean,
    val job_google_link: String? = null,
    val job_id: String? = null,
    val job_is_remote: Boolean,
    val job_job_title: String? = null,
    val job_latitude: Double?,
    val job_longitude: Double?,
    val job_naics_code: String? = null,
    val job_naics_name: String? = null,
    val job_occupational_categories: List<String?>,
    val job_offer_expiration_datetime_utc: String? = null,
    val job_offer_expiration_timestamp: Int?,
    val job_onet_job_zone: String? = null,
    val job_onet_soc: String? = null,
    val job_posted_at_datetime_utc: String? = null,
    val job_posted_at_timestamp: Int?,
    val job_posting_language: String? = null,
    val job_publisher: String? = null,
    val job_required_education: JobRequiredEducation?,
    val job_required_experience: JobRequiredExperience?,
    val job_required_skills: List<String?>,
    val job_state: String? = null,
    val job_title: String? = null
):Parcelable