package com.example.aajivikasetu.screen.fragment.mainadmin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentPaymentPendingStatusBinding
import com.example.aajivikasetu.di.UserModel
import com.google.firebase.database.DatabaseReference
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PaymentPendingStatusFragment : Fragment() {
    private var _binding : FragmentPaymentPendingStatusBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    @UserModel
    lateinit var userDatabaseReference: DatabaseReference
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentPaymentPendingStatusBinding.inflate(inflater, container, false)

        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }

        return binding.root
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}