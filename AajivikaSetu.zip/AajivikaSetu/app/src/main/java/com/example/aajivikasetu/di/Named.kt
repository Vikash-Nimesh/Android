package com.example.aajivikasetu.di

import javax.inject.Qualifier

@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class UserModel

@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class AdminModel

@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class VolunteerModel


@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class BloodDetails


@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class LoneRequest