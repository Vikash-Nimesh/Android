package com.example.aajivikasetu.model.personaldetails

data class KeySkills(
    var skill : String = "",
    val workStatus : String = "",
    var areaOfEx : String = "",
    var expYear : String = ""
)
