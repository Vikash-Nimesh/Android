package com.example.aajivikasetu.screen.fragment.main

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.aajivikasetu.databinding.FragmentShowProfileDetailsBinding
import com.example.aajivikasetu.di.UserModel
import com.example.aajivikasetu.model.personaldetails.UserDetails
import com.example.aajivikasetu.screen.fragment.main.state.ShowProfileViewModel
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.showAlertDialogWithEditText
import com.google.firebase.database.DatabaseReference
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ShowProfileDetails : Fragment() {
   private var _binding : FragmentShowProfileDetailsBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    private lateinit var progressbar: ProgressDialog

    @Inject
    lateinit var sharedManager: SharedManager

    @Inject
    @UserModel
    lateinit var databaseReference: DatabaseReference
    private val showProfileViewModel by viewModels<ShowProfileViewModel>()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentShowProfileDetailsBinding.inflate(inflater, container, false)
        setUpProgressDialog()
        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }

        if (sharedManager.getImageUrl().isNotEmpty()){
            Glide.with(requireContext()).load(sharedManager.getImageUrl()).into(binding.profileImage)
        }

        val userId = sharedManager.getUserUuid()
        showProfileViewModel.getUserData(userId)

        showProfileViewModel.userData.observe(viewLifecycleOwner) {
            when(it){
                is ResultState.Loading ->{
                    binding.progressCircular.visibility = View.VISIBLE
                    binding.linearLayoutContent.visibility = View.GONE
                }
                is ResultState.Success -> {
                    if (it.data != null){
                        fillTheData(it.data)
                    }
                    binding.progressCircular.visibility = View.GONE
                    binding.linearLayoutContent.visibility = View.VISIBLE
                }
                is ResultState.Error ->{
                    binding.progressCircular.visibility = View.GONE
                    binding.linearLayoutContent.visibility = View.VISIBLE
                    Toast.makeText(requireContext(), it.message.toString(), Toast.LENGTH_LONG).show()
                }
            }
        }

        binding.addSummary.setOnClickListener {
            requireContext().showAlertDialogWithEditText { summary ->
                if (summary.isNotEmpty()){
                    val updateMap = mapOf(
                        "personalDetails/summery" to summary
                    )

                    progressbar.show()
                    databaseReference.child(sharedManager.getUserUuid()).updateChildren(updateMap).addOnCompleteListener {
                        if (it.isSuccessful){
                            showToast("Profile summary add successful")
                            binding.profileSummery.text = summary
                            progressbar.dismiss()
                        }
                    }.addOnFailureListener {
                        showToast("something went to wrong")
                        progressbar.dismiss()
                    }
                }
            }
        }

        return binding.root
    }

    @SuppressLint("SetTextI18n")
    private fun fillTheData(data: UserDetails) {
        binding.apply {
            profileSummery.text = data.personalDetails?.summery
            nameOfUser.text = "Name: "+data.name
            userPhone.text = "Phone: "+data.personalDetails?.phone
            email.text = "Email Id: "+data.email
            gender.text = "Gender: "+data.personalDetails?.gender
            dateOdBirth.text = "Date of Birth: "+data.personalDetails?.dob
            matitalStatus.text = "Marital Status: "+data.personalDetails?.maritalStatus
            nationality.text = "Nationality: "+data.personalDetails?.nationality
            language.text = "Language: "+data.personalDetails?.language
            address.text = "Address: "+data.personalDetails?.address

            // for the education details
            secondarySchool.text = "Secondary School: "+data.educationDetails?.secondarySchool
            higherSchool.text = "Higher Secondary School: "+data.educationDetails?.higherSecondarySchool
            diploma.text = "Diploma : "+data.educationDetails?.diploma
            bachelors.text = "Bachelor's : "+data.educationDetails?.bachelor
            postGraduation.text = "Post Graduation : "+data.educationDetails?.postGrade
            doctorate.text = "Doctorate/Phd : "+data.educationDetails?.doctorate

            // for the career details
            currentIndustry.text = "Current Industry: "+data.careerDetails?.currentIndustry
            department.text = "Department: "+data.careerDetails?.department
            desiredJobRole.text = "Desired Job Role: "+data.careerDetails?.desiredJobRole
            preferedworkshift.text = "Preferred Work Shift: "+data.careerDetails?.preferredWorkShift
            preferedworkLocation.text = "Preferred Work location: "+data.careerDetails?.preferredWorkLocation

            // for the key skill
            keySkills.text = "Key Skill: "+data.keySkill?.skill
            workStatus.text = "Work Status: "+data.keySkill?.workStatus
            areaOfExperience.text = "Area of Experience: "+data.keySkill?.areaOfEx
            experienceInYear.text = "Experience in year: "+data.keySkill?.expYear

            //
            workSample.text = "Work Sample: "+data.keySkill?.workStatus
        }
    }

    private fun showToast(message : String){
        Toast.makeText(
            requireContext(),
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun setUpProgressDialog() {
        progressbar = ProgressDialog(requireContext())
        progressbar.setMessage("Loading...")
        progressbar.setCancelable(false)
        progressbar.create()
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}