package com.example.aajivikasetu.screen.fragment.mainadmin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aajivikasetu.databinding.FragmentBloodDonarDataBinding
import com.example.aajivikasetu.screen.fragment.mainadmin.state.BloodDonarDataViewModel
import com.example.aajivikasetu.screen.fragment.mainadmin.state.BloodDonnerAdapter
import com.example.aajivikasetu.utils.ResultState
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BloodDonarDataFragment : Fragment() {
    private var _binding : FragmentBloodDonarDataBinding ?= null
    private val binding : FragmentBloodDonarDataBinding by lazy { requireNotNull(_binding) }
    private val bloodDonarData by viewModels<BloodDonarDataViewModel>()
    private lateinit var bloodDonnerAdapter: BloodDonnerAdapter
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentBloodDonarDataBinding.inflate(layoutInflater, container, false)
        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }
        showData()
        return binding.root
    }

    private fun showData() {
        bloodDonarData.bloodDonnerData.observe(viewLifecycleOwner){
            when(it){
                is ResultState.Loading ->{
                    binding.progressBar.visibility = View.VISIBLE
                }
                is ResultState.Success ->{
                    binding.progressBar.visibility = View.GONE
                    bloodDonnerAdapter = BloodDonnerAdapter(it.data!!)
                    binding.recyclerViewBlood.apply {
                        adapter = bloodDonnerAdapter
                        this.layoutManager = LinearLayoutManager(requireContext())
                        this.hasFixedSize()
                    }
                }
                is ResultState.Error ->{
                    binding.progressBar.visibility  = View.GONE
                    Toast.makeText(requireContext(), it.message.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}