package com.example.aajivikasetu.sharedpref

import android.content.SharedPreferences
import javax.inject.Inject

class SharedManager @Inject constructor (private val sharedPreferences: SharedPreferences)  {
    fun setUserData(name : String, email : String, uuid : String){
        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putString("email", email)
        editor.putString("uuid", uuid)
        editor.apply()
    }

    fun getEmailId() : String{
        return sharedPreferences.getString("email", null) ?: ""
    }
    fun getName() : String{
        return sharedPreferences.getString("name", null) ?: ""
    }

    fun setPhoneNumber(phoneNumber : String){
        val editor = sharedPreferences.edit()
        editor.putString("phoneNumber", phoneNumber)
        editor.apply()
    }

    fun setImageUrl(url : String){
        val editor = sharedPreferences.edit()
        editor.putString("image_url", url)
        editor.apply()
    }

    fun setVolunteerReferenceId(referenceId : String){
        val editor = sharedPreferences.edit()
        editor.putString("volRef", referenceId)
        editor.apply()
    }

    fun getReference() : String{
        return sharedPreferences.getString("volRef", null) ?: ""
    }


    fun getImageUrl() : String{
        return sharedPreferences.getString("image_url", null) ?: ""
    }


    fun getUserUuid(): String {
        return sharedPreferences.getString("uuid", "") ?: ""
    }

    fun getUserPhoneNumber(): String {
        return sharedPreferences.getString("phoneNumber", null) ?: ""
    }

    fun addAuthData(userUuid : String){
        val editor = sharedPreferences.edit()
        editor.putString("authData", userUuid)
        editor.apply()
    }

    fun addLanguageData(language : String){
        val editor = sharedPreferences.edit()
        editor.putString("languageData", language)
        editor.apply()
    }

    fun addPermission(permission : String) {
        val editor = sharedPreferences.edit()
        editor.putString("permissionData", permission)
        editor.apply()
    }

    fun isAuthPassed() : Boolean{
        val data = sharedPreferences.getString("authData", null)
        return data != null
    }

    fun isLanguagePassed() : Boolean{
        val data = sharedPreferences.getString("languageData", null)
        return data != null

    }

    fun userLogIn(userUuid: String){
        val editor = sharedPreferences.edit()
        editor.putString("isUserLogIn", userUuid)
        editor.apply()
    }

    fun adminLogIn(userUuid: String){
        val editor = sharedPreferences.edit()
        editor.putString("isAdminLogIn", userUuid)
        editor.apply()
    }

    fun volunteerLogIn(userUuid: String){
        val editor = sharedPreferences.edit()
        editor.putString("isVolunteerLogIn", userUuid)
        editor.apply()
    }

    fun isUserLogIn() : Boolean{
        return sharedPreferences.getString("isUserLogIn", null) != null
    }

    fun isAdminLogIn() : Boolean{
        return sharedPreferences.getString("isAdminLogIn", null) != null
    }

    fun isVolunteerLogIn() : Boolean{
        return sharedPreferences.getString("isVolunteerLogIn", null) != null
    }

    fun isPermissionPassed(): Boolean {
        return sharedPreferences.getString("permissionData", null) != null
    }

    fun storeLanguage(language: String){
        val editor = sharedPreferences.edit()
        editor.putString("storeLanguage", language)
        editor.apply()
    }

    fun getAppLanguage() : String{
        return sharedPreferences.getString("storeLanguage", "") ?: ""
    }

    fun paymentId(paymentId : String){
        val editor = sharedPreferences.edit()
        editor.putString("paymentId", paymentId)
        editor.apply()
    }

    fun getPaymentId() : String?{
        return sharedPreferences.getString("paymentId", null)
    }


    fun clearSharedPreferences() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }
}