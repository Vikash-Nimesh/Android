package com.example.aajivikasetu.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aajivikasetu.databinding.SkillLayoutBinding

class SkillAdapter(private val list: List<SkillAndCheckBox>, var listOfItem: (List<String>) -> Unit) : RecyclerView.Adapter<SkillAdapter.SkillVH>() {

    class SkillVH(val binding: SkillLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkillVH {
        return SkillVH(SkillLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: SkillVH, position: Int) {
        val currentItem = list[position]
        holder.binding.apply {
            skillName.text = currentItem.text
            checkSkill.isChecked = currentItem.isChecked // Set the initial state

            checkSkill.setOnCheckedChangeListener { _, isChecked ->
                currentItem.isChecked = isChecked

                // Update the list of checked items
                val checkedItems = list.filter { it.isChecked }.map { it.text }
                listOfItem(checkedItems)
            }
        }
    }

}
