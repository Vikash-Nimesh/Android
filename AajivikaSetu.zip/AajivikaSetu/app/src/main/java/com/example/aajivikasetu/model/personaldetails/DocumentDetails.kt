package com.example.aajivikasetu.model.personaldetails

data class DocumentDetails(
    var resume : String = "",
    var other : String = ""
)