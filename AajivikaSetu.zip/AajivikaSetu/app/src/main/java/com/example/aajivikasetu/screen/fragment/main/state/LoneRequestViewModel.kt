package com.example.aajivikasetu.screen.fragment.main.state

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aajivikasetu.model.lonedata.LoneRequestDataModel
import com.example.aajivikasetu.repo.Repository
import com.example.aajivikasetu.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class LoneRequestViewModel @Inject constructor(private val repository: Repository) : ViewModel(){
    val requestLoneLiveData : LiveData<ResultState<String>> = repository.loneRequestLiveData

    fun putLoneRequestData(data : LoneRequestDataModel, uuid : String){
        viewModelScope.launch {
            repository.loneRequest(data, uuid)
        }
    }
}