package com.example.aajivikasetu.utils

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.GraphRequest
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult

class FacebookAuthenticationHelper(private val fragment : Fragment, private val callbackManager: CallbackManager) {
    fun performLogin(onSuccess: (String, String, String?, String) -> Unit, onCancel: () -> Unit, onError: (String) -> Unit) {
        LoginManager.getInstance().logInWithReadPermissions(fragment, listOf("email", "public_profile"))
        LoginManager.getInstance().registerCallback(callbackManager, object : FacebookCallback<LoginResult> {
            override fun onSuccess(result: LoginResult) {
                val accessToken = result.accessToken
                val request = GraphRequest.newMeRequest(accessToken) { obj, _ ->
                    try {
                        val userId = accessToken.userId
                        val userName = obj?.getString("name").toString()
                        val email = obj?.optString("email")
                        val imageUrl = obj?.getJSONObject("picture")?.getJSONObject("data")?.getString("url").toString()

                        onSuccess(userId, userName, email, imageUrl)
                    } catch (e: Exception) {
                        onError(e.message.toString())
                    }
                }
                val parameters = Bundle()
                parameters.putString("fields", "id,name,email,link,picture.type(large)")
                request.parameters = parameters
                request.executeAsync()
            }

            override fun onCancel() {
                onCancel()
            }

            override fun onError(error: FacebookException) {
                onError(error.message.toString())
            }
        })
    }
}