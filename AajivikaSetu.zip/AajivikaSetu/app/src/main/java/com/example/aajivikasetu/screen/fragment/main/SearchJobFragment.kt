package com.example.aajivikasetu.screen.fragment.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentSearchJobBinding

class SearchJobFragment : Fragment() {
    private var _binding : FragmentSearchJobBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentSearchJobBinding.inflate(inflater, container, false)


        return binding.root
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}