package com.example.aajivikasetu.screen.fragment.permission

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentPermissionBinding
import com.example.aajivikasetu.sharedpref.SharedManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PermissionFragment : Fragment() {
    private var _binding: FragmentPermissionBinding? = null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    lateinit var sharedManager: SharedManager
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPermissionBinding.inflate(inflater, container, false)

        binding.agreeButton.setOnClickListener {
            sharedManager.addPermission("permission_granted")

            if (sharedManager.isUserLogIn()) {
                findNavController().navigate(
                    R.id.dashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.permissionFragment, true).build()
                )
            } else if(sharedManager.isAdminLogIn()){
                findNavController().navigate(
                    R.id.adminDashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.permissionFragment, true).build()
                )
            } else {
                findNavController().navigate(
                    R.id.volunteerDashBoardFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.permissionFragment, true).build()
                )
            }
        }

        return binding.root
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}