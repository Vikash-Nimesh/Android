package com.example.aajivikasetu.screen.fragment.mainadmin.state

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aajivikasetu.databinding.BloodDonnarCardDetailsBinding
import com.example.aajivikasetu.model.blooddonar.BloodDonorData

class BloodDonnerAdapter(private val list: List<BloodDonorData>) : RecyclerView.Adapter<BloodDonnerAdapter.BloodDonnerVH>(){
    class BloodDonnerVH(val bloodDonnerCardBinding : BloodDonnarCardDetailsBinding) : RecyclerView.ViewHolder(bloodDonnerCardBinding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BloodDonnerVH {
        return BloodDonnerVH(BloodDonnarCardDetailsBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: BloodDonnerVH, position: Int) {
        val data = list[position]
        holder.bloodDonnerCardBinding.apply {
            nameDonner.text = "Name: ${data.name}"
            bloodGroup.text = "Blood Group: ${data.bloodGroup}"
            phoneDonner.text = "Phone: ${data.phoneNo}"
            cityDonner.text = "City: ${data.city}"
            districtDonner.text = "District: ${data.district}"
            stateDonner.text = "State: ${data.state}"
        }
    }
}