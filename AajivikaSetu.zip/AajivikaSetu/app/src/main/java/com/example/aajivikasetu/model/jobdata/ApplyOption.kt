package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class ApplyOption(
    val apply_link: String?,
    val is_direct: Boolean,
    val publisher: String?
):Parcelable