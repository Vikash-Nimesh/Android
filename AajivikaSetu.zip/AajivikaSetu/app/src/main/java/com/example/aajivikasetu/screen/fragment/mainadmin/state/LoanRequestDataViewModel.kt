package com.example.aajivikasetu.screen.fragment.mainadmin.state

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aajivikasetu.model.lonedata.LoneRequestDataModel
import com.example.aajivikasetu.repo.Repository
import com.example.aajivikasetu.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoanRequestDataViewModel @Inject constructor(private val repository: Repository) : ViewModel() {
   val loanRequestLiveData : LiveData<ResultState<List<LoneRequestDataModel>>> = repository.loanRequestLiveData
    init {
        viewModelScope.launch {
            repository.getAllLoanRequestCustomers()
        }
    }
}