package com.example.aajivikasetu.screen.fragment.main.state

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aajivikasetu.model.blooddonar.BloodDonorData
import com.example.aajivikasetu.repo.Repository
import com.example.aajivikasetu.utils.ResultState
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NeedBloodDonnerViewModel @Inject constructor(private val repository: Repository) : ViewModel() {
    val bloodDonnerLiveData : LiveData<ResultState<List<BloodDonorData>>> = repository.needBloodDonnerLiveData

    fun getBloodDonnerData(email : String, lat : String, log : String){
        viewModelScope.launch {
            repository.needBloodDonarData(email, lat, log)
        }
    }
}