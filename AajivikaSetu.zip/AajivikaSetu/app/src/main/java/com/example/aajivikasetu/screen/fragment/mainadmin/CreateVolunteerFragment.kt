package com.example.aajivikasetu.screen.fragment.mainadmin

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.databinding.FragmentCreateVolunteerBinding
import com.example.aajivikasetu.di.VolunteerModel
import com.example.aajivikasetu.model.VolunteerModelData
import com.example.aajivikasetu.utils.ProgressBarDialog
import com.example.aajivikasetu.utils.generateRandomReferenceId
import com.example.aajivikasetu.utils.hashPassword
import com.example.aajivikasetu.utils.isInternetAvailable
import com.example.aajivikasetu.utils.isValidEmail
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.database.DatabaseReference
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class CreateVolunteerFragment : Fragment() {
    private var _binding : FragmentCreateVolunteerBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }

    @Inject
    @VolunteerModel
    lateinit var volunteerDatabaseReference: DatabaseReference

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var progressBarDialog: ProgressBarDialog

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentCreateVolunteerBinding.inflate(inflater, container, false)

        firebaseAuth = FirebaseAuth.getInstance()
        progressBarDialog = ProgressBarDialog(requireActivity())

        binding.createVolunteerButton.setOnClickListener {
            if (credentialValid()){
                resisteredUser()
            }
        }


        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun resisteredUser() {
        val name = binding.userName.text.toString().trim()
        val email = binding.userEmail.text.toString().trim()
        val password = binding.userPassword.text.toString()
        val phone = binding.userPhone.text.toString()

        if (isInternetAvailable(requireContext())){
            progressBarDialog.startDialog()
            firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener {
                if (it.isSuccessful){
                    val uuid = firebaseAuth.currentUser?.uid.toString()
                    val volunteerData = VolunteerModelData(name, email,phone,"", uuid, hashPassword(password), generateRandomReferenceId(), 0)

                    volunteerDatabaseReference.child(uuid).setValue(volunteerData).addOnCompleteListener { task ->
                        if (task.isSuccessful){

                            findNavController().popBackStack()
                            showMessage("volunteer created successfully")

                            progressBarDialog.isDismiss()

                        }else{
                            progressBarDialog.isDismiss()
                            showMessage("failed")
                        }
                    }
                }else{
                    val exception: Exception? = it.exception
                    if (exception is FirebaseAuthUserCollisionException) {
                        showMessage("this email is already exits, please try with another email")
                        progressBarDialog.isDismiss()
                    } else {
                        showMessage(exception?.message.toString())
                        progressBarDialog.isDismiss()
                    }
                }
            }.addOnFailureListener {
                showMessage("Somethings went to wrong")
                progressBarDialog.isDismiss()
            }
        }else{
            progressBarDialog.isDismiss()
            showMessage("No internet connection")
        }
    }

    private fun credentialValid(): Boolean {
        val name = binding.userName
        val email = binding.userEmail
        val phone = binding.userPhone
        val password = binding.userPassword

        if (name.text.toString().isEmpty()){
            name.error = "Please enter name"
            return false
        }else if (email.text.toString().isEmpty()) {
            email.error = "Please write email"
            return false
        } else if (!isValidEmail(email.text.toString().trim())){
            email.error = "Enter valid email"
            return false
        }else if (phone.text.toString().isEmpty()){
            phone.error = "Please enter phone number"
            return false
        }else if (phone.text.length != 10){
            phone.error = "Please enter valid phone number"
            return false
        } else if (password.text.toString().isEmpty()){
            password.error = "Please enter password"
            return false
        } else if (password.text.toString().length < 6){
            password.error = "Password should be greater the 6 characters"
            return false
        }
        return true
    }

    private fun showMessage(message : String){
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}