package com.example.aajivikasetu.utils

/*
*
* <com.google.android.material.textfield.TextInputLayout
                    android:layout_width="match_parent"
                    android:layout_marginTop="@dimen/_10sdp"
                    android:layout_height="wrap_content">

                    <com.google.android.material.textfield.TextInputEditText
                        android:layout_width="match_parent"
                        android:hint="@string/full_name"
                        android:textColor="@color/black"
                        android:fontFamily="@font/nunito_medium"
                        android:id="@+id/full_name"
                        android:layout_height="wrap_content"/>
                </com.google.android.material.textfield.TextInputLayout>


                <com.google.android.material.textfield.TextInputLayout
                    android:layout_width="match_parent"
                    android:layout_marginTop="@dimen/_10sdp"
                    android:layout_height="wrap_content">

                    <com.google.android.material.textfield.TextInputEditText
                        android:layout_width="match_parent"
                        android:hint="Date of Birth"
                        android:textColor="@color/black"
                        android:fontFamily="@font/nunito_medium"
                        android:id="@+id/dateOfBirth"
                        android:layout_height="wrap_content"/>

                </com.google.android.material.textfield.TextInputLayout>


                <com.google.android.material.textfield.TextInputLayout
                    android:layout_width="match_parent"
                    android:layout_marginTop="@dimen/_10sdp"
                    android:layout_height="wrap_content">

                    <com.google.android.material.textfield.TextInputEditText
                        android:layout_width="match_parent"
                        android:hint="Phone Number"
                        android:textColor="@color/black"
                        android:fontFamily="@font/nunito_medium"
                        android:id="@+id/phone_number"
                        android:layout_height="wrap_content"/>

                </com.google.android.material.textfield.TextInputLayout>*/