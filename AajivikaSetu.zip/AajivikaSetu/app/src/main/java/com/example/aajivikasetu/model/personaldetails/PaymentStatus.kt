package com.example.aajivikasetu.model.personaldetails

data class PaymentStatus(
    var status : String = "",
    var id : String = "",
    var date : String = "",
    var totalPayment : String = ""
)
