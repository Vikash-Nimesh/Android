package com.example.aajivikasetu.screen.fragment.auth

import android.app.AlertDialog
import android.app.LocaleManager
import android.content.Context
import android.content.DialogInterface
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.withStateAtLeast
import androidx.navigation.NavDeepLinkRequest
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentMainLogInBinding
import com.example.aajivikasetu.screen.fragment.lang.LocalHelper
import com.example.aajivikasetu.sharedpref.SharedManager
import com.facebook.FacebookSdk.getApplicationContext
import dagger.hilt.android.AndroidEntryPoint
import hilt_aggregated_deps._dagger_hilt_android_flags_FragmentGetContextFix_FragmentGetContextFixEntryPoint
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class MainLogInFragment : Fragment() {
    private var _binding: FragmentMainLogInBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    @Inject
    lateinit var sharedManager: SharedManager
    private lateinit var context: Context
    private lateinit var resources: Resources
    private lateinit var selectLanguage : String


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentMainLogInBinding.inflate(inflater, container, false)

        binding.userButton.setOnClickListener { findNavController().navigate(R.id.action_mainLogInFragment_to_userLogInFragment) }
        binding.adminButton.setOnClickListener { findNavController().navigate(R.id.action_mainLogInFragment_to_adminLogInFragment) }
        binding.volunteerButton.setOnClickListener { findNavController().navigate(R.id.action_mainLogInFragment_to_volunteerLogInFragment) }

        binding.selectLanguage.setOnClickListener {
            changeLanguage()
        }

        return binding.root
    }

    private fun changeLanguage() {
        val language = arrayOf("English", "हिंदी")
        val alertBuilder = AlertDialog.Builder(requireContext())
        alertBuilder.setTitle("Choose Language")
        alertBuilder.setSingleChoiceItems(language, 0) { dialog: DialogInterface?, which: Int ->
            selectLanguage = when (which) {
                0 -> "en"
                1 -> "hi"
                else -> "en"
            }


            context = LocalHelper.setLocale(requireContext(), selectLanguage)
            resources = context.resources
            activity?.recreate()


            dialog?.dismiss()
        }
        alertBuilder.create()
        alertBuilder.show()
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}