package com.example.aajivikasetu.model.lonedata

data class LoneRequestDataModel(
    val name : String = "",
    val email : String = "",
    val phone : String = "",
    val amount : String = "",
    val requestDate : String = "",
    val address : Address? = null
)

data class Address(
    val localAdd : String = "",
    val state : String = "",
    val district : String = "",
    val city : String = "",
)