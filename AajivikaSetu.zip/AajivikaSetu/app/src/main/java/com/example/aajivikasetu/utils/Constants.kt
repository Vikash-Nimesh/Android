package com.example.aajivikasetu.utils

object Constants {
    const val BASE_URL = "https://jsearch.p.rapidapi.com/"
    const val Local_Data = "local_data"

    const val UserModel = "UserData"
    const val AdminModel = "AdminData"
    const val VolunteerModel = "VolunteerData"
    const val BloodDetails = "bloodDetails"
    const val LoneRequest = "loneRequest"
}