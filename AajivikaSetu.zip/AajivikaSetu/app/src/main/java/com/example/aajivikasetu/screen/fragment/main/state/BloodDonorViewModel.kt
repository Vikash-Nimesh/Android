package com.example.aajivikasetu.screen.fragment.main.state

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aajivikasetu.model.blooddonar.BloodDonorData
import com.example.aajivikasetu.repo.Repository
import com.example.aajivikasetu.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BloodDonorViewModel @Inject constructor(private  val repository: Repository) : ViewModel() {
    val bloodDetails : LiveData<ResultState<String>> get() = repository.bloodLiveData

    fun addBloodData(data : BloodDonorData, uuid : String){
        viewModelScope.launch {
            repository.addBloodDetailsData(data, uuid)
        }
    }
}