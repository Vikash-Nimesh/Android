package com.example.aajivikasetu.screen.fragment.main

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aajivikasetu.databinding.FragmentNeedBloodBinding
import com.example.aajivikasetu.screen.fragment.main.state.NeedBloodDonnerViewModel
import com.example.aajivikasetu.screen.fragment.mainadmin.state.BloodDonnerAdapter
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.showAlert
import com.example.aajivikasetu.utils.showToast
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class NeedBloodFragment : Fragment() {
    private var _binding: FragmentNeedBloodBinding? = null
    private val binding: FragmentNeedBloodBinding by lazy { requireNotNull(_binding) }
    private val needBloodDonnerViewModel by viewModels<NeedBloodDonnerViewModel>()
    private lateinit var bloodDonnerAdapter: BloodDonnerAdapter

    @Inject
    lateinit var sharedManager: SharedManager

    private var latitude: String? = null
    private var longitude: String? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val locationPermission = Manifest.permission.ACCESS_FINE_LOCATION

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                getLocation{ _, _ ->

                }
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), locationPermission)
                ) {
                    showPermissionRationale()
                }
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNeedBloodBinding.inflate(inflater, container, false)
        val email = sharedManager.getEmailId()

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                locationPermission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            getLocation{ latitude: String, longitude: String ->
                Log.d("datacomss", "$latitude $longitude")

                showBloodDonnerData(email)
            }
        } else {
            requestPermissionLauncher.launch(locationPermission)
        }



        binding.arrowBack.setOnClickListener { findNavController().popBackStack() }

        return binding.root
    }

    private fun showBloodDonnerData(email: String) {
        if (latitude != null && longitude != null) {
            needBloodDonnerViewModel.getBloodDonnerData(email, latitude!!, longitude!!)
            needBloodDonnerViewModel.bloodDonnerLiveData.observe(viewLifecycleOwner) {
                when (it) {
                    is ResultState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                    }

                    is ResultState.Success -> {
                        binding.progressBar.visibility = View.GONE
                        bloodDonnerAdapter = BloodDonnerAdapter(it.data!!)
                        binding.recyclerViewBlood.apply {
                            adapter = bloodDonnerAdapter
                            layoutManager = LinearLayoutManager(requireContext())
                            hasFixedSize()
                        }
                    }

                    is ResultState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(requireContext(), it.message.toString(), Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            }
        } else {
            // open app info and provide the location
            requireContext().showToast("provide the location permission")
        }
    }

    private fun getLocation(callback: (latitude: String, longitude: String) -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            showPermissionRationale()
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    latitude = location.latitude.toString()
                    longitude = location.longitude.toString()
                    callback.invoke(location.latitude.toString(), location.longitude.toString())
                }
            }
            .addOnFailureListener { e ->
                requireContext().showToast(e.message.toString())
            }
    }

    private fun showPermissionRationale() {
        requireContext().showAlert(
            "Location Permission Required",
            "We need your location to provide you with relevant information.",
            onOkayClick = {
                requestPermissionLauncher.launch(locationPermission)
            },
            onNoClick = {
                requestPermissionLauncher.launch(locationPermission)
            }
        )
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}