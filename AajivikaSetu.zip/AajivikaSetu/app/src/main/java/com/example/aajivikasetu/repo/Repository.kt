package com.example.aajivikasetu.repo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.aajivikasetu.di.BloodDetails
import com.example.aajivikasetu.di.LoneRequest
import com.example.aajivikasetu.di.UserModel
import com.example.aajivikasetu.model.blooddonar.BloodDonorData
import com.example.aajivikasetu.model.lonedata.LoneRequestDataModel
import com.example.aajivikasetu.model.personaldetails.UserDetails
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.calculateDistance
import com.google.firebase.database.DatabaseReference
import javax.inject.Inject

class Repository @Inject constructor(
    @UserModel private val databaseReference: DatabaseReference,
    @BloodDetails private val bloodDetailsDatabaseReference: DatabaseReference,
    @LoneRequest private val loneRequestDatabaseReference: DatabaseReference
) {
    private var _mutableUserData: MutableLiveData<ResultState<UserDetails>> = MutableLiveData()
    val userData: LiveData<ResultState<UserDetails>> = _mutableUserData

    fun getUserData(userId: String) {
        _mutableUserData.postValue(ResultState.Loading())
        databaseReference.child(userId).get().addOnSuccessListener {
            try {
                if (it.exists()) {
                    val data = it.getValue(UserDetails::class.java)
                    if (data != null) {
                        _mutableUserData.postValue(ResultState.Success(data))
                    } else {
                        _mutableUserData.postValue(ResultState.Error("not data"))
                    }
                } else {
                    _mutableUserData.postValue(ResultState.Error("Not exit"))
                }
            } catch (e: Exception) {
                _mutableUserData.postValue(ResultState.Error(e.message.toString()))
            }
        }.addOnFailureListener {
            _mutableUserData.postValue(ResultState.Error(it.message.toString()))
        }
    }


    /*---------------------------------------------------------------------------------------------------------------------------------*/
    private val _bloodDetailsMutableLiveData: MutableLiveData<ResultState<String>> = MutableLiveData()
    val bloodLiveData: LiveData<ResultState<String>> = _bloodDetailsMutableLiveData

    fun addBloodDetailsData(data: BloodDonorData, uuid: String) {
        _bloodDetailsMutableLiveData.postValue(ResultState.Loading())
        try {
            bloodDetailsDatabaseReference.child(uuid).setValue(data).addOnCompleteListener {
                if (it.isSuccessful) {
                    _bloodDetailsMutableLiveData.postValue(ResultState.Success("Data uploaded successful"))
                } else {
                    _bloodDetailsMutableLiveData.postValue(ResultState.Error("Something went to wrong"))
                }
            }.addOnFailureListener {
                _bloodDetailsMutableLiveData.postValue(ResultState.Error(it.message))
            }
        } catch (e: Exception) {
            _bloodDetailsMutableLiveData.postValue(ResultState.Error(e.message.toString()))
        }
    }


    /*---------------------------------------------------------------------------------------------------------------------------------*/
    private val loneRequestMutableLiveData: MutableLiveData<ResultState<String>> = MutableLiveData()
    val loneRequestLiveData: LiveData<ResultState<String>> = loneRequestMutableLiveData

    fun loneRequest(data: LoneRequestDataModel, uuid: String) {
        loneRequestMutableLiveData.postValue(ResultState.Loading())
        try {
            loneRequestDatabaseReference.child(uuid).setValue(data).addOnCompleteListener {
                if (it.isSuccessful) {
                    loneRequestMutableLiveData.postValue(ResultState.Success("Data uploaded successful"))
                } else {
                    loneRequestMutableLiveData.postValue(ResultState.Error("Something went to wrong"))
                }
            }.addOnFailureListener {
                loneRequestMutableLiveData.postValue(ResultState.Error(it.message))
            }
        } catch (e: Exception) {
            loneRequestMutableLiveData.postValue(ResultState.Error(e.message.toString()))
        }
    }

    /*--------------------------------------------------------------------------------------------------------------------------------------*/
    private val bloodDonnerDataMutable: MutableLiveData<ResultState<List<BloodDonorData>>> = MutableLiveData()
    val bloodDonnerLiveData: LiveData<ResultState<List<BloodDonorData>>> = bloodDonnerDataMutable

    fun getAllBloodDonnerData() {
        bloodDonnerDataMutable.postValue(ResultState.Loading())
        bloodDetailsDatabaseReference.get().addOnCompleteListener { it ->
            if (it.isSuccessful) {
                val data: MutableList<BloodDonorData> = mutableListOf()
                it.result.children.forEach {
                    val d = it.getValue(BloodDonorData::class.java)
                    if (d != null) {
                        data.add(d)
                    }
                }
                if (data.isNotEmpty()) {
                    bloodDonnerDataMutable.postValue(ResultState.Success(data))
                } else {
                    bloodDonnerDataMutable.postValue(ResultState.Error("No Data"))
                }
            } else {
                bloodDonnerDataMutable.postValue(ResultState.Error("Somethings went to wrong"))
            }
        }.addOnFailureListener {
            bloodDonnerDataMutable.postValue(ResultState.Error(it.message.toString()))
        }
    }

    /*----------------------------------------------------------------------------------------------------------------------------*/

    private val loanRequestMutableLiveData: MutableLiveData<ResultState<List<LoneRequestDataModel>>> = MutableLiveData()
    val loanRequestLiveData: LiveData<ResultState<List<LoneRequestDataModel>>> =
        loanRequestMutableLiveData

    fun getAllLoanRequestCustomers() {
        loanRequestMutableLiveData.postValue(ResultState.Loading())
        loneRequestDatabaseReference.get().addOnCompleteListener { it ->
            if (it.isSuccessful) {
                val data: MutableList<LoneRequestDataModel> = mutableListOf()
                it.result.children.forEach {
                    val d = it.getValue(LoneRequestDataModel::class.java)
                    if (d != null) {
                        data.add(d)
                    }
                }
                if (data.isNotEmpty()) {
                    loanRequestMutableLiveData.postValue(ResultState.Success(data))
                } else {
                    loanRequestMutableLiveData.postValue(ResultState.Error("No Data"))
                }
            } else {
                loanRequestMutableLiveData.postValue(ResultState.Error("Somethings went to wrong"))
            }
        }.addOnFailureListener {
            loanRequestMutableLiveData.postValue(ResultState.Error(it.message.toString()))
        }
    }


    /*--------------------------------------------------------------------------------------------------------------------------------------*/
    private val needBloodDonarMutableLiveData: MutableLiveData<ResultState<List<BloodDonorData>>> = MutableLiveData()
    val needBloodDonnerLiveData: LiveData<ResultState<List<BloodDonorData>>> = needBloodDonarMutableLiveData

    fun needBloodDonarData(email: String, lat: String, log: String) {
        needBloodDonarMutableLiveData.postValue(ResultState.Loading())
        bloodDetailsDatabaseReference.get().addOnCompleteListener { it ->
            if (it.isSuccessful) {
                val data: MutableList<BloodDonorData> = mutableListOf()
                it.result.children.forEach {
                    val d = it.getValue(BloodDonorData::class.java)
                    if (d != null && d.email != email) {

                        if (d.geo?.lat != null && d.geo?.log != null){
                            val distance = calculateDistance(d.geo?.lat!!.toDouble(), d.geo?.log!!.toDouble(), lat.toDouble(), log.toDouble())

                            // Check if the distance is within the 30 km radius
                            val radius = 30.0
                            if (distance <= radius) {
                                data.add(d)
                            }
                        }


                    }
                }
                if (data.isNotEmpty()) {
                    needBloodDonarMutableLiveData.postValue(ResultState.Success(data))
                } else {
                    needBloodDonarMutableLiveData.postValue(ResultState.Error("No Data"))
                }
            } else {
                needBloodDonarMutableLiveData.postValue(ResultState.Error("Somethings went to wrong"))
            }
        }.addOnFailureListener {
            needBloodDonarMutableLiveData.postValue(ResultState.Error(it.message.toString()))
        }
    }
}