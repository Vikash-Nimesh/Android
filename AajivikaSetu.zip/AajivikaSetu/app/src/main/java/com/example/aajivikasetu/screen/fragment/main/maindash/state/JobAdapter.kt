package com.example.aajivikasetu.screen.fragment.main.maindash.state

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.bumptech.glide.Glide
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.JobPagingCardBinding
import com.example.aajivikasetu.model.jobdata.Data
import com.example.aajivikasetu.utils.formateDate

class JobAdapter : PagingDataAdapter<Data, JobAdapter.JobViewHolder>(differCallback) {
    private lateinit var context: Context
    private var jobCardClick: CardClick? = null

    inner class JobViewHolder(val jobLayoutCardBinding: JobPagingCardBinding) :
        ViewHolder(jobLayoutCardBinding.root)

    companion object {
        val differCallback = object : DiffUtil.ItemCallback<Data>() {
            override fun areItemsTheSame(oldItem: Data, newItem: Data): Boolean {
                return oldItem.job_id == newItem.job_id
            }

            override fun areContentsTheSame(oldItem: Data, newItem: Data): Boolean {
                return oldItem == newItem
            }
        }
    }


    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        val currentItem = getItem(position)
        /*holder.jobLayoutCardBinding.jobTitile.text = currentItem?.job_job_title
        holder.jobLayoutCardBinding.apply {
            applyOption.adapter = currentItem?.apply_options?.let {
                ApplyOptionAdapter(it)
            }
            applyOption.layoutManager = LinearLayoutManager(context)
            applyOption.hasFixedSize()
        }*/

        holder.jobLayoutCardBinding.apply {
            if (currentItem?.job_job_title != null) {
                jobTitle.text = currentItem.job_job_title
            } else {
                jobTitle.text = currentItem?.job_title
            }


            if (currentItem?.job_city != null) {
                jobLocation.text = currentItem.job_city
                jobLocation.visibility = View.VISIBLE
            } else {
                jobLocation.visibility = View.GONE
            }

            if (currentItem?.job_offer_expiration_datetime_utc != null) {
                lastDate.text =
                    "Last Date: " + currentItem.job_offer_expiration_datetime_utc.formateDate()
                lastDate.visibility = View.VISIBLE
            } else {
                lastDate.visibility = View.GONE
            }
            employeementType.text = currentItem?.job_employment_type
            if (currentItem?.employer_logo != null) {
                Glide.with(context).load(currentItem.employer_logo).into(jobImageLogo)
            } else {
                jobImageLogo.setImageResource(R.drawable.hand_shake)
            }
        }

        holder.jobLayoutCardBinding.jobCardView.setOnClickListener {
            jobCardClick?.onJobCardClick(currentItem)
        }


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        context = parent.context
        return JobViewHolder(
            jobLayoutCardBinding = JobPagingCardBinding.inflate(
                LayoutInflater.from(
                    parent.context
                ), parent, false
            )
        )
    }

    fun jobCardClick(cardClick: CardClick) {
        this.jobCardClick = cardClick
    }

    interface CardClick {
        fun onJobCardClick(currentItem: Data?)
    }

}