package com.example.aajivikasetu.screen.fragment.main.maindash.state

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.aajivikasetu.model.jobdata.Data
import com.example.aajivikasetu.network.JobService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JobViewModel @Inject constructor(private val jobService: JobService) : ViewModel() {
    private val _pagingData: MutableLiveData<PagingData<Data>> = MutableLiveData()
    //val pagingData: LiveData<PagingData<Data>> = _pagingData

    val pagingData = Pager(
        config = PagingConfig(pageSize = 10),
        pagingSourceFactory = { JobPagingSource(jobService, "all india") }
    ).flow.cachedIn(viewModelScope).asLiveData()

    fun getJob(searchJob : String = "all india") {
        _pagingData.postValue(Pager(
            config = PagingConfig(pageSize = 10),
            pagingSourceFactory = { JobPagingSource(jobService, searchJob) }
        ).flow.cachedIn(viewModelScope).asLiveData().value)
    }
}


/*val pagingData = _searchJob.switchMap { searchJob ->
    Pager(
        config = PagingConfig(pageSize = 10),
        pagingSourceFactory = { JobPagingSource(jobService, "all india") }
    ).flow.cachedIn(viewModelScope).asLiveData()
}*/

/*val pagingData: LiveData<PagingData<Data>> = _searchJob.switchMap { searchJob ->
       Pager(
           config = PagingConfig(pageSize = 10),
           pagingSourceFactory = { JobPagingSource(jobService, searchJob) }
       ).flow.cachedIn(viewModelScope).asLiveData()
   }*/