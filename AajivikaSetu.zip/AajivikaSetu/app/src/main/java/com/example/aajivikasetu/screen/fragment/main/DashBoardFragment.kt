package com.example.aajivikasetu.screen.fragment.main

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentDashBoardBinding
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.showAlertDialog
import com.example.aajivikasetu.utils.showAlertDialogWithEditText
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DashBoardFragment : Fragment() {
    private var _binding : FragmentDashBoardBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    private lateinit var drawerLayout: DrawerLayout
    @Inject
    lateinit var sharedManager: SharedManager

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentDashBoardBinding.inflate(inflater, container, false)
        drawerLayout = binding.myDrawerLayout

        firebaseAuth = FirebaseAuth.getInstance()

        binding.menuDrawer.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
        binding.profileName.text = sharedManager.getName()
        if (sharedManager.getImageUrl().isNotEmpty()){
            Glide.with(requireContext()).load(sharedManager.getImageUrl()).into(binding.profileImage)
        }

        onclickHandle()

        // handling back handler
        val onBackPressedCallback = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                }else{
                    requireActivity().finishAffinity()
                }
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, onBackPressedCallback)


        return binding.root
    }

    private fun onclickHandle() {
        binding.apply {
            // for the drawer layout
            updateProfile.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_profileFragment)
            }

            searchJobs.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_searchJobFragment)
            }

            recommendedJobs.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_recommendedJobFragment)
            }

            SavedJobs.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_savedJobFragment)
            }

            setting.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_settingsFragment)
            }

            aboutUs.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_aboutUsFragment)
            }

            // for the main screen
            showProfileDetailsButton.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_showProfileDetails)
            }
            createResumeButton.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_profileFragment)
            }
            exploreJobButton.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_exploreJobFragment)
            }
            requestLoanButton.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_loneRequestFragment)
            }
            bloodRequestButton.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_bloodDonationFragment)
            }

            needBlood.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_needBloodFragment)
            }

            postJob.setOnClickListener {
                findNavController().navigate(R.id.action_dashBoardFragment_to_postJobFragment)
            }

            supportButton.setOnClickListener {

            }

            logout.setOnClickListener {
                requireActivity().showAlertDialog("Want to Log out?", "Your session is ticking away! Are you sure you want to log out now?", onOkayClick = {
                    sharedManager.clearSharedPreferences()
                    firebaseAuth.signOut()
                    findNavController().navigate(
                        R.id.mainLogInFragment,
                        null,
                        NavOptions.Builder().setPopUpTo(R.id.dashBoardFragment, true).build()
                    )
                }, onCancelClick = {
                    it.dismiss()
                })
            }
        }
    }


    override fun onResume() {
        super.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}