package com.example.aajivikasetu.screen.fragment.main.maindash

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentExploreJobBinding
import com.example.aajivikasetu.model.jobdata.Data
import com.example.aajivikasetu.screen.fragment.main.maindash.state.JobAdapter
import com.example.aajivikasetu.screen.fragment.main.maindash.state.JobSharedViewModel
import com.example.aajivikasetu.screen.fragment.main.maindash.state.JobViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExploreJobFragment : Fragment() {
    private var _binding : FragmentExploreJobBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    private val jobViewModel by viewModels<JobViewModel> ()
    private lateinit var jobAdapter : JobAdapter
    private var isFirstTimeRefreshing = true
    private val jobSharedViewModel: JobSharedViewModel by activityViewModels()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentExploreJobBinding.inflate(inflater, container, false)
        jobAdapter = JobAdapter()

        jobViewModel.pagingData.observe(viewLifecycleOwner){
            jobAdapter.submitData(lifecycle, it)
        }

        setUpRecyclerView()

        binding.jobSearchButton.setOnClickListener {
            val searchJob = binding.searchJobEdit.text.toString()
            if (searchJob.isNotEmpty()){
                jobViewModel.getJob(searchJob)
            }else{
                binding.searchJobEdit.error = "enter job name"
            }
        }

        jobAdapter.jobCardClick(object : JobAdapter.CardClick {
            override fun onJobCardClick(currentItem: Data?) {
                if (currentItem != null){
                    jobSharedViewModel.selectJob(currentItem)
                    findNavController().navigate(R.id.action_exploreJobFragment_to_jobDescriptionFragment)
                }
            }
        })

        return binding.root
    }

    private fun setUpRecyclerView() {
        binding.recyclerViewVeilForPaging.apply {
            setAdapter(jobAdapter)
            setLayoutManager(LinearLayoutManager(requireContext()))
            addVeiledItems(9)
        }

        jobAdapter.addLoadStateListener { loadState ->
            // show empty list
            if (loadState.refresh is LoadState.Loading || loadState.append is LoadState.Loading){
                if (isFirstTimeRefreshing){
                    binding.recyclerViewVeilForPaging.veil()
                }else{
                    binding.progressBar.visibility = View.VISIBLE
                    binding.recyclerViewVeilForPaging.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                        this.setMargins(0,0,0,100)
                    }
                }
            }else{
                if (isFirstTimeRefreshing){
                    binding.recyclerViewVeilForPaging.postDelayed({
                        binding.recyclerViewVeilForPaging.unVeil()
                        isFirstTimeRefreshing = false
                    },2000)
                }
                binding.progressBar.visibility = View.INVISIBLE
                binding.recyclerViewVeilForPaging.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                    setMargins(0,0,0,0)
                }
                // if an error then show toast
                val errorState = when{
                    loadState.append is LoadState.Error ->loadState.append as LoadState.Error
                    loadState.prepend is LoadState.Error -> loadState.prepend as LoadState.Error
                    loadState.refresh is LoadState.Error -> loadState.refresh as LoadState.Error
                    else -> null
                }
                errorState?.apply {
                    Toast.makeText(requireContext(), "${this.error}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}