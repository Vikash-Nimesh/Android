package com.example.aajivikasetu.model.personaldetails

import com.example.aajivikasetu.model.blooddonar.Geo

data class PersonalDetails(
    var summery : String = "",
    var image : String = "",
    var phone : String = "",
    var gender : String = "",
    var dob : String = "",
    var maritalStatus : String = "",
    var nationality : String = "",
    var language : String = "",
    var address : String = "",
    val geo: Geo ?= null
)