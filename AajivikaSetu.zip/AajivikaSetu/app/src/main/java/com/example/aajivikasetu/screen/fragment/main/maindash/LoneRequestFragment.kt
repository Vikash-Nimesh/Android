package com.example.aajivikasetu.screen.fragment.main.maindash

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.aajivikasetu.R
import com.example.aajivikasetu.databinding.FragmentLoneRequestBinding
import com.example.aajivikasetu.model.lonedata.Address
import com.example.aajivikasetu.model.lonedata.LoneRequestDataModel
import com.example.aajivikasetu.screen.fragment.main.state.LoneRequestViewModel
import com.example.aajivikasetu.sharedpref.SharedManager
import com.example.aajivikasetu.utils.ResultState
import com.example.aajivikasetu.utils.StateAndDistrict
import com.example.aajivikasetu.utils.getCurrentDateTimeFormatted
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


@AndroidEntryPoint
class LoneRequestFragment : Fragment() {
    private var _binding : FragmentLoneRequestBinding ?= null
    private val binding by lazy { requireNotNull(_binding) }
    private val loneRequestViewModel by viewModels<LoneRequestViewModel>()

    @Inject
    lateinit var sharedManager: SharedManager
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentLoneRequestBinding.inflate(inflater, container, false)

        binding.arrowBack.setOnClickListener {
            findNavController().popBackStack()
        }

        val state = StateAndDistrict.states
        val name = sharedManager.getName()
        val email = sharedManager.getEmailId()
        val phone = sharedManager.getUserPhoneNumber()


        binding.userName.setText(name)
        binding.userEmail.setText(email)
        binding.userPhone.setText(phone)


        val stateAdapter = ArrayAdapter(requireContext(), R.layout.category_list, state)
        binding.state.setAdapter(stateAdapter)

        var selectedDistrict: String? = null
        binding.state.setOnItemClickListener { _, _, position, _ ->
            val selectedState = stateAdapter.getItem(position).toString()
            val districtList = StateAndDistrict.initializeTheDistrict(selectedState)

            if (districtList != null) {
                val districtAdapter = ArrayAdapter(requireContext(), R.layout.category_list, districtList)
                binding.district.setAdapter(districtAdapter)

                // Restore the selected district if available
                if (selectedDistrict != null && districtList.contains(selectedDistrict)) {
                    val districtPosition = districtList.indexOf(selectedDistrict)
                    binding.district.setText(selectedDistrict, false)
                    binding.district.setSelection(districtPosition)
                } else {
                    binding.district.setText("", false)
                }
            }
        }

        binding.submitButton.setOnClickListener {
            if (validCredential()){
                insertDataInDatabase()
            }
        }

        return binding.root
    }

    private fun insertDataInDatabase() {
        val name = binding.userName.text.toString()
        val email = binding.userEmail.text.toString()
        val phone = binding.userPhone.text.toString()
        val amount = binding.loneAmount.text.toString()
        val requestLoneData = getCurrentDateTimeFormatted()
        val address = binding.addressLocal.text.toString()
        val state = binding.state.text.toString()
        val district = binding.district.text.toString()
        val city = binding.cityName.text.toString()
        val progress = binding.progeress

        val data = LoneRequestDataModel(name, email, phone, amount, requestLoneData, address = Address(address, state, district, city))
        loneRequestViewModel.putLoneRequestData(data, sharedManager.getUserUuid())
        loneRequestViewModel.requestLoneLiveData.observe(viewLifecycleOwner){
            when(it){
                is ResultState.Loading -> {
                    progress.visibility = View.VISIBLE
                }
                is ResultState.Success ->{
                    progress.visibility = View.GONE
                    showToast(it.data.toString())
                    findNavController().popBackStack()
                }
                is ResultState.Error -> {
                    progress.visibility = View.GONE
                    showToast(it.message.toString())
                }
            }
        }
    }

    private fun validCredential(): Boolean {
        val name = binding.userName
        val email = binding.userEmail
        val phone = binding.userPhone
        val amount = binding.loneAmount
        val address = binding.addressLocal
        val city = binding.cityName
        if (name.text.isEmpty()){
            name.error = "Please write the name"
            return false
        }else if (email.text.isEmpty()){
            email.error = "please enter the email"
            return false
        }else if (phone.text.isEmpty()) {
            phone.error = "enter phone number"
            return false
        } else if (phone.text.length != 10) {
            phone.error = "enter valid phone number"
            return false
        }else if (!phone.text.startsWith("6") && !phone.text.startsWith("7") &&
            !phone.text.startsWith("8") && !phone.text.startsWith("9")) {
            phone.error = "enter correct number"
            return false
        } else if (amount.text.isEmpty()){
            amount.error = "enter lone amount"
            return false
        } else if (address.text.isEmpty()){
            address.error = "enter local address"
            return false
        } else if (binding.state.text.isEmpty()){
            showToast("please select the state")
            return false
        }else if (binding.district.text.isEmpty()){
            showToast("please select the district")
            return false
        }else if (city.text.isEmpty()){
            city.error = "please enter the city"
        }

        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
    private fun showToast(message : String){
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

}