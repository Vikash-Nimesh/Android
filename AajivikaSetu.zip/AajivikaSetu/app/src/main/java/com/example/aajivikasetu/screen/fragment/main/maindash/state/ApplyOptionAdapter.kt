package com.example.aajivikasetu.screen.fragment.main.maindash.state

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aajivikasetu.databinding.ApplyOptionLayoutBinding
import com.example.aajivikasetu.model.jobdata.ApplyOption

class ApplyOptionAdapter(private var applyOptionAdapter : List<ApplyOption>) : RecyclerView.Adapter<ApplyOptionAdapter.ApplyOptionViewHolder>() {
    private var onApplyButton: OnApplyButtonClick ?= null
    class ApplyOptionViewHolder(val applyOptionLayoutBinding: ApplyOptionLayoutBinding) : RecyclerView.ViewHolder(applyOptionLayoutBinding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ApplyOptionViewHolder {
        return ApplyOptionViewHolder(ApplyOptionLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return applyOptionAdapter.size
    }

    override fun onBindViewHolder(holder: ApplyOptionViewHolder, position: Int) {
        val currentItem = applyOptionAdapter[position]
        holder.applyOptionLayoutBinding.apply {
            this.companyApplyName.text = currentItem.publisher
        }

        holder.applyOptionLayoutBinding.applyButton.setOnClickListener {
            onApplyButton?.onApplyButton(currentItem.apply_link)
        }
    }

    fun applyButton(onApplyButtonClick: OnApplyButtonClick){
        onApplyButton = onApplyButtonClick
    }

    interface OnApplyButtonClick{
        fun onApplyButton(applyLink: String?)
    }
}