package com.example.aajivikasetu.model.jobdata

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class JobRequiredEducation(
    val associates_degree: Boolean,
    val bachelors_degree: Boolean,
    val degree_mentioned: Boolean,
    val degree_preferred: Boolean,
    val high_school: Boolean,
    val postgraduate_degree: Boolean,
    val professional_certification: Boolean,
    val professional_certification_mentioned: Boolean
):Parcelable