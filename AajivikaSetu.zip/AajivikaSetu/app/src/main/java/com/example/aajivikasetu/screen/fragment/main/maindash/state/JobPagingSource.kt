package com.example.aajivikasetu.screen.fragment.main.maindash.state

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.aajivikasetu.model.jobdata.Data
import com.example.aajivikasetu.model.jobdata.JobDataModel
import com.example.aajivikasetu.network.JobService
import javax.inject.Inject

class JobPagingSource @Inject constructor(private val jobServices : JobService,private val searchJob : String) : PagingSource<Int, Data>(){
    override fun getRefreshKey(state: PagingState<Int, Data>): Int? {
        return null
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Data> {
        return try {
            val page = params.key ?: 1
            val response = jobServices.getJobData(searchJob, page, 1)// "all, india"
            val data = response.data

            LoadResult.Page(
                data = data,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (data.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }
}