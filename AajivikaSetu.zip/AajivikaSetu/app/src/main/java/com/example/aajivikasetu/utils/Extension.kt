package com.example.aajivikasetu.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.aajivikasetu.R
import com.example.aajivikasetu.model.blooddonar.Geo
import com.example.aajivikasetu.model.personaldetails.CareerDetails
import com.example.aajivikasetu.model.personaldetails.DocumentDetails
import com.example.aajivikasetu.model.personaldetails.EducationDetails
import com.example.aajivikasetu.model.personaldetails.KeySkills
import com.example.aajivikasetu.model.personaldetails.PaymentStatus
import com.example.aajivikasetu.model.personaldetails.PersonalDetails
import com.example.aajivikasetu.model.personaldetails.UserDetails
import com.google.android.material.snackbar.Snackbar
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale
import java.util.Random
import java.util.regex.Pattern
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt


fun isValidEmail(email: String): Boolean {
    val pattern: Pattern = Patterns.EMAIL_ADDRESS
    return pattern.matcher(email).matches()
}

@RequiresApi(Build.VERSION_CODES.M)
fun isInternetAvailable(context: Context): Boolean {
    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = connectivityManager.activeNetwork ?: return false
    val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false

    return when {
        activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
        activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
        else -> false
    }
}

class ProgressBarDialog(private val activity: Activity) {
    private lateinit var isDialog: AlertDialog

    fun startDialog() {
        val inflate = activity.layoutInflater
        val dialogView = inflate.inflate(R.layout.progress_dialog, null)

        val builder = AlertDialog.Builder(activity)
        builder.setView(dialogView)
        builder.setCancelable(false)
        isDialog = builder.create()
        isDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        isDialog.show()
    }

    fun isDismiss() {
        isDialog.dismiss()
    }
}


private var loadingDialog: Dialog? = null

/*@SuppressLint("SetTextI18n")
fun Context.showLoading() {
    if (loadingDialog?.isShowing == true) {
        return
    }

    loadingDialog = Dialog(this)
    loadingDialog?.setContentView(R.layout.dialog_loading)
    loadingDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    loadingDialog?.setCancelable(false)

    val progressBar = loadingDialog?.findViewById<ProgressBar>(R.id.progressBar)
    val titleTextView = loadingDialog?.findViewById<TextView>(R.id.titleTextView)
    titleTextView?.text = "Loading..."

    val layoutParams = RelativeLayout.LayoutParams(
        RelativeLayout.LayoutParams.WRAP_CONTENT,
        RelativeLayout.LayoutParams.WRAP_CONTENT
    )
    progressBar?.layoutParams = layoutParams

    loadingDialog?.show()
}*/

/*fun Context.hideLoading() {
    loadingDialog?.dismiss()
}*/

fun showSnackbar(message: String, view: View) {
    val snackbar = Snackbar.make(view, message, Snackbar.LENGTH_SHORT)
    val snackbarView = snackbar.view

    val params = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    params.gravity = Gravity.TOP

    val parentLayout = view as ViewGroup
    parentLayout.addView(snackbarView, params)
    snackbar.show()
}

fun hashPassword(password: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    val hashedBytes = md.digest(password.toByteArray())
    return hashedBytes.joinToString("") { "%02x".format(it) }
}

fun isPasswordCorrect(originalPassword: String, storedHashedPassword: String): Boolean {
    val hashedEnteredPassword = hashPassword(originalPassword)
    return hashedEnteredPassword == storedHashedPassword
}

fun Context.showToast(message : String){
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}


fun Context.showAlert(
    title: String,
    message: String,
    onOkayClick: () -> Unit,
    onNoClick: () -> Unit
) {
    val builder = AlertDialog.Builder(this)
    builder.setCancelable(false)
    builder.setTitle(title).setMessage(message).setPositiveButton("Yes") { _, _ ->
        onOkayClick()
    }
        .setNegativeButton("No") { dialog, _ ->
            onNoClick()
            dialog.dismiss()
        }.create().show()
}

@SuppressLint("Range")
fun Uri.getFileName(activity: Activity): String {
    var result: String? = null
    if (this.scheme == "content") {
        val cursor = activity.contentResolver?.query(this, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                result = it.getString(it.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                    ?: this.lastPathSegment
            }
        }
    }
    if (result == null) {
        result = this.path
        val cut = result?.lastIndexOf('/')
        if (cut != -1) {
            result = result?.substring(cut!! + 1)
        }
    }
    return result ?: "Unknown"
}

fun UserDetails.toMap(): Map<String, Any?> {
    return mapOf(
        "name" to name,
        "personalDetails" to personalDetails?.toMap(),
        "educationDetails" to educationDetails?.toMap(),
        "careerDetails" to careerDetails?.toMap(),
        "keySkill" to keySkill?.toMap(),
        "document" to document?.toMap(),
        "paymentStatus" to paymentStatus?.toMap()
    )
}

fun PersonalDetails.toMap(): Map<String, Any?> {
    return mapOf(
        "summery" to summery,
        "image" to image,
        "phone" to phone,
        "gender" to gender,
        "dob" to dob,
        "maritalStatus" to maritalStatus,
        "nationality" to nationality,
        "language" to language,
        "address" to address,
        "geo" to geo?.toMap()
    )
}

fun Geo.toMap() : Map<String, Any?> {
    return mapOf(
        "lat" to lat,
        "log" to log
    )
}


fun EducationDetails.toMap(): Map<String, Any?> {
    return mapOf(
        "secondarySchool" to secondarySchool,
        "higherSecondarySchool" to higherSecondarySchool,
        "diploma" to diploma,
        "bachelor" to bachelor,
        "postGrade" to postGrade,
        "doctorate" to doctorate
    )
}

fun CareerDetails.toMap(): Map<String, Any?> {
    return mapOf(
        "currentIndustry" to currentIndustry,
        "department" to department,
        "desiredJobRole" to desiredJobRole,
        "preferredWorkShift" to preferredWorkShift,
        "preferredWorkLocation" to preferredWorkLocation
    )
}

fun KeySkills.toMap(): Map<String, Any?> {
    return mapOf(
        "skill" to skill,
        "workStatus" to workStatus,
        "areaOfEx" to areaOfEx,
        "expYear" to expYear
    )
}

fun DocumentDetails.toMap(): Map<String, Any?> {
    return mapOf(
        "resume" to resume,
        "other" to other
    )
}

fun PaymentStatus.toMap(): Map<String, Any?> {
    return mapOf(
        "status" to status,
        "id" to id,
        "date" to date,
        "totalPayment" to totalPayment
    )
}

fun Context.showAlertDialogWithEditText(onOkClick: (String) -> Unit) {
    val inputEditTextField = EditText(this)
    val dialog = AlertDialog.Builder(this)
        .setTitle("Upload Profile Summary")
        .setMessage("Write profile summary")
        .setView(inputEditTextField)
        .setPositiveButton("OK") { _, _ ->
            val editTextInput = inputEditTextField.text.toString()
            onOkClick(editTextInput)
        }
        .setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        .create()

    dialog.show()
}

fun Context.showAlertDialog(
    titile: String,
    message: String,
    onOkayClick: () -> Unit,
    onCancelClick: (DialogInterface) -> Unit
) {
    val dialog = AlertDialog.Builder(this)
        .setTitle(titile)
        .setMessage(message)
        .setPositiveButton("Yes") { dialog, _ ->
            onOkayClick()
        }
        .setNegativeButton("No") { dialog, _ ->
            onCancelClick(dialog)
        }
        .create()
    dialog.show()
}

@RequiresApi(Build.VERSION_CODES.O)
fun String.formateDate(): String {
    val instant = Instant.parse(this)
    val dateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
    val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
    return dateTime.format(formatter)
}

fun Context.isPackageInstalled(): Boolean {
    val packageManager = this.packageManager
    return try {
        packageManager.getPackageInfo("com.android.chrome", PackageManager.GET_ACTIVITIES)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}

fun getCurrentDateTimeFormatted(): String {
    val currentDateTime = Calendar.getInstance().time
    val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(currentDateTime)
}


fun generateRandomReferenceId(): String {
    val random = Random(System.currentTimeMillis())
    val characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    val referenceId = StringBuilder()

    repeat(6) {
        val randomIndex = random.nextInt(characters.length)
        referenceId.append(characters[randomIndex])
    }
    return referenceId.toString()
}

// Haversine formula to calculate the distance between their latitude and longitude coordinates
fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371 // Earth radius in kilometers
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c
}

fun main() {
    // User A coordinates
    val userALatitude = 27.029399
    val userALongitude = 84.384734

    // User B coordinates
    val userBLatitude = 26.754370
    val userBLongitude = 84.662027

    // Calculate distance between A and B
    val distanceBetweenAB = calculateDistance(userALatitude, userALongitude, userBLatitude, userBLongitude)

    // Check if the distance is within the 30 km radius
    val radius = 30.0
    if (distanceBetweenAB <= radius) {
        println("User A and User B are within $radius km of each other.")
    } else {
        println("User A and User B are more than $radius km apart.")
    }
}